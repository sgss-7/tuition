// Imports a TUITIONAPP backup file (the JSON from Admin > Backup and restore) into Supabase.
//
//   cd tools && npm install
//   SUPABASE_URL=https://xxxx.supabase.co SUPABASE_SERVICE_KEY=eyJ... \
//     node import-backup.mjs ../tuitionapp-backup-2026-10-24.json --owner-email you@example.com --owner-password 'a long password'
//
// --owner-email/--owner-password create the admin login (use these if nobody has run the app's first-time setup yet).
// Leave them out if you already created the admin by opening the app first; the data is then imported into that centre.
// --dry-run checks the file and prints counts without writing. The service key stays on your computer; never put it in the app.
import { readFileSync } from 'node:fs';
import { toDb, ORDER } from '../js/dbmap.js';

const args = process.argv.slice(2);
const file = args.find((a) => !a.startsWith('--') && !/^(--)/.test(a) && a.endsWith('.json'));
const opt = (n) => { const i = args.indexOf('--' + n); return i >= 0 ? args[i + 1] : undefined; };
const dry = args.includes('--dry-run');
const { SUPABASE_URL, SUPABASE_SERVICE_KEY } = process.env;
if (!file || (!dry && (!SUPABASE_URL || !SUPABASE_SERVICE_KEY))) {
  console.error('Usage: SUPABASE_URL=... SUPABASE_SERVICE_KEY=... node import-backup.mjs backup.json [--owner-email e --owner-password p] [--dry-run]');
  process.exit(1);
}

const bk = JSON.parse(readFileSync(file, 'utf8'));
if (bk.app !== 'TUITIONAPP' || !bk.data) { console.error('That is not a TUITIONAPP backup file.'); process.exit(1); }
const D = {}; ORDER.forEach((t) => { D[t] = Array.isArray(bk.data[t]) ? bk.data[t].slice() : []; });

/* ---- make references consistent (Firestore never enforced them, Postgres does) ---- */
const ids = (t) => new Set(D[t].map((r) => r.id));
const notes = [];
function dropWhere(t, label, bad) { const n = D[t].length; D[t] = D[t].filter((r) => !bad(r)); if (n !== D[t].length) notes.push(`${t}: skipped ${n - D[t].length} ${label}`); }
function clearRef(t, field, set) { let n = 0; D[t].forEach((r) => { if (r[field] && !set.has(r[field])) { r[field] = null; n++; } }); if (n) notes.push(`${t}: cleared ${n} dangling ${field}`); }
clearRef('batches', 'teacherId', ids('staff'));
clearRef('students', 'batchId', ids('batches'));
dropWhere('fees', 'rows for missing students', (r) => !ids('students').has(r.studentId));
dropWhere('att', 'rows for missing students', (r) => !ids('students').has(r.studentId));
dropWhere('marks', 'rows for missing students', (r) => !ids('students').has(r.studentId));
dropWhere('marks', 'rows for missing tests', (r) => !ids('tests').has(r.testId));
clearRef('homework', 'batchId', ids('batches'));
dropWhere('salary', 'rows for missing teachers', (r) => !ids('staff').has(r.staffId));
clearRef('claims', 'feeId', ids('fees'));

console.log('Records to import:'); ORDER.forEach((t) => D[t].length && console.log('  ' + t.padEnd(10), D[t].length));
notes.forEach((n) => console.log('  note: ' + n));
if (dry) { console.log('Dry run, nothing written.'); process.exit(0); }

const { createClient } = await import('@supabase/supabase-js');
const sb = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY, { auth: { persistSession: false, autoRefreshToken: false } });
const must = (r, what) => { if (r.error) { console.error(`Failed: ${what}: ${r.error.message}`); process.exit(1); } return r; };

/* ---- admin login ---- */
const email = opt('owner-email'), pw = opt('owner-password');
const centre = (D.settings.find((s) => s.id === 'main') || {}).centre || 'My centre';
if (email && pw) {
  const { data: info } = await sb.from('public_info').select('id').eq('id', 'info').maybeSingle();
  if (info) { console.error('This project is already set up (public_info exists). Re-run without --owner-email.'); process.exit(1); }
  const c = must(await sb.auth.admin.createUser({ email, password: pw, email_confirm: true }), 'create admin');
  must(await sb.from('profiles').insert({ id: c.data.user.id, role: 'owner', name: 'Admin', email }), 'admin profile');
  must(await sb.from('public_info').insert({ id: 'info', centre, created: Date.now() }), 'public_info');
  console.log('Admin created:', email);
}

/* ---- data, parents before children ---- */
for (const t of ORDER) {
  const rows = D[t].map((r) => { const { id, ...rest } = r; return toDb(t, id, rest); });
  for (let i = 0; i < rows.length; i += 400) must(await sb.from(t).upsert(rows.slice(i, i + 400), { onConflict: 'id' }), `import ${t}`);
  if (rows.length) console.log(`  imported ${t}: ${rows.length}`);
}
/* teacher logins cannot be copied (passwords are not in a backup), so mark them as needing a new password */
const t = D.staff.filter((s) => s.login);
if (t.length) {
  must(await sb.from('staff').update({ login: false }).in('id', t.map((s) => s.id)), 'reset login flags');
  console.log(`\n${t.length} teacher(s) need a new password: Admin > Teachers > Edit > set password.`);
}
console.log('\nDone.');
