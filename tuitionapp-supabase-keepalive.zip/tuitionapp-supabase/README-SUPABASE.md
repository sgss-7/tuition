# TUITIONAPP on Supabase

## 1. Create the project
1. supabase.com > New project. Save the database password.
2. **Authentication > Providers > Email**: turn **Confirm email OFF** (the admin signs up once and is signed in straight away).
3. **SQL Editor**: paste all of `supabase/schema.sql` and run it.

## 2. Connect the app
Project Settings > API: copy the **Project URL** and the **anon public** key into `js/supabase-config.js`.
(Never use the `service_role` key in the app.)

## 3. Teacher logins (Edge Function)
```
npm i -g supabase
supabase login
supabase link --project-ref <your-project-ref>
supabase functions deploy manage-login
```
Authentication > URL Configuration: set Site URL to where the app is hosted (password-reset emails land on `reset.html`).

## 4. Move your Firebase data
1. In the **old** app: Admin > Backup and restore > Download backup.
2. Then:
```
cd tools && npm install
SUPABASE_URL=https://<ref>.supabase.co SUPABASE_SERVICE_KEY=<service_role key> \
  node import-backup.mjs ../your-backup.json --owner-email you@example.com --owner-password '<8+ chars>' --dry-run
```
Remove `--dry-run` to write. Leave out `--owner-*` if you already created the admin by opening the new app first.
3. Teachers: passwords are not in a backup. Admin > Teachers > Edit > type a new password for each.
4. Parents never had logins, nothing to move.

## 5. Host it
Upload this folder to any static host (Firebase Hosting, Netlify, Vercel, Cloudflare Pages). `app.html` is the app.

## What changed
- `js/store.js` rewritten for Supabase. Same exported functions, so `main.js` has only small edits (messages, three Firebase calls).
- `js/dbmap.js` maps records to table rows. Fields without a column go to each table's `extra` column, so nothing is lost.
- `supabase/schema.sql` replaces `firestore.rules` (row level security with the same owner/teacher rules).
- Removed: `firestore.rules`, `js/firebase-config.js`.

## Weekly backup to Google Drive (optional)
Copies all your data to your own Google Drive every Saturday at 6 am (Nepal time) and keeps 120 days of copies.

1. **Pick a secret.** Make up a long random text, at least 30 characters, letters and numbers only. Keep it private: it unlocks your data.
2. **Save it in Supabase.** Edge Functions > **Secrets** > add `BACKUP_KEY` with your secret as the value.
3. **Deploy the function.** Edge Functions > Deploy a new function > Via Editor. Name it `export-backup`, paste in `supabase/functions/export-backup/index.ts`, and deploy.
   Then open the function's **Settings** and turn **Verify JWT** OFF. Save. (The secret is what protects it.)
4. **Create the Google script.** Go to script.google.com > New project. Delete the sample code, paste in `drive/backup.gs`, and replace `PASTE_YOUR_LONG_SECRET_HERE` with your secret. Save.
5. In the function drop-down at the top choose **installWeeklyTrigger** > Run. Allow access when Google asks (click Advanced > Go to project if it warns).
6. Choose **backupNow** > Run. A folder **TUITIONAPP backups** appears in your Drive with today's file. In the app, Admin > Backup shows today's date.

To restore, use Admin > Backup and restore > Restore from file and pick a file from that folder.

## Keep the project from pausing (free plan)
Free Supabase projects pause after 7 days with no activity. Two ways to prevent it; the first needs nothing new.

**A. Google Drive script (already set up above).** `drive/backup.gs` now also has `keepAlive`, which reads one row every 2 days. Paste the new `backup.gs`, then run **installWeeklyTrigger** once more. It re-creates both triggers (Saturday backup + keepAlive every 2 days). Run **keepAlive** once to test: no error means it worked.

**B. GitHub Actions (backup plan, independent of Google).** Put this repo on GitHub. `.github/workflows/keepalive.yml` pings the database every 3 days. It needs no secrets because it only uses the public anon key. GitHub turns off scheduled runs after 60 days with no commits, so make a small commit now and then, or just use A.

If the project is already paused, press **Restore project** in the Supabase dashboard (data is kept for 90 days).
