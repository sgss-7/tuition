// Creates and removes teacher logins. Teachers sign in with a phone number, so each gets a private made-up email.
// Only the owner may call this. Deploy: supabase functions deploy manage-login
// SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are provided automatically to Edge Functions.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};
const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...cors, 'Content-Type': 'application/json' } });

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return json({ error: 'POST only' }, 405);

  const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  // who is calling, and are they the owner?
  const jwt = (req.headers.get('Authorization') || '').replace(/^Bearer\s+/i, '');
  const { data: who, error: whoErr } = await admin.auth.getUser(jwt);
  if (whoErr || !who.user) return json({ error: 'Not signed in', code: 'permission-denied' }, 401);
  const { data: me } = await admin.from('profiles').select('role').eq('id', who.user.id).maybeSingle();
  if (!me || me.role !== 'owner') return json({ error: 'Only the admin can do this', code: 'permission-denied' }, 403);

  let b: any;
  try { b = await req.json(); } catch { return json({ error: 'Bad request' }, 400); }
  const role = 'teacher';                                   // parents have no login
  const phone = String(b.phone || '').replace(/\D/g, '').slice(-10);
  if (b.role !== role || phone.length !== 10) return json({ error: 'Bad phone or role' }, 400);
  const key = `${role}_${phone}`;

  const { data: old } = await admin.from('loginmap').select('uid').eq('key', key).maybeSingle();

  if (b.action === 'drop') {
    if (old?.uid) await admin.auth.admin.deleteUser(old.uid);   // profiles and loginmap rows cascade
    await admin.from('loginmap').delete().eq('key', key);
    return json({ ok: true });
  }

  if (b.action === 'make') {
    const pw = String(b.password || '');
    if (pw.length < 6) return json({ error: 'Password too short', code: 'auth/weak-password' }, 400);
    const rnd = Array.from(crypto.getRandomValues(new Uint8Array(4))).map((x) => x.toString(16).padStart(2, '0')).join('');
    const email = `${role}${phone}-${rnd}@${role}s.example.com`;
    const { data: created, error: cErr } = await admin.auth.admin.createUser({ email, password: pw, email_confirm: true });
    if (cErr || !created.user) return json({ error: cErr?.message || 'Could not create login', code: (cErr as any)?.code }, 400);
    const uid2 = created.user.id;

    const { error: pErr } = await admin.from('profiles').insert({
      id: uid2, role, name: String(b.name || ''), phone, email, staff_id: b.staffId || null,
    });
    if (pErr) { await admin.auth.admin.deleteUser(uid2); return json({ error: pErr.message }, 400); }
    // point the phone number at the new login, then remove the old one (this is how a password is reset)
    const { error: mErr } = await admin.from('loginmap').upsert({ key, email, uid: uid2 }, { onConflict: 'key' });
    if (mErr) { await admin.auth.admin.deleteUser(uid2); return json({ error: mErr.message }, 400); }
    if (old?.uid && old.uid !== uid2) await admin.auth.admin.deleteUser(old.uid);
    return json({ uid: uid2, replaced: !!old?.uid });
  }

  return json({ error: 'Unknown action' }, 400);
});
