// Returns a full backup of the centre's data as JSON, in the same format as Admin > Download backup.
// Called weekly by drive/backup.gs (Google Apps Script), which saves it to Google Drive.
// Protected by a secret: send it in the x-backup-key header. Set the secret as BACKUP_KEY in Edge Function secrets.
// This function must have "Verify JWT" turned OFF, because Apps Script has no Supabase login.
// SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are provided to Edge Functions automatically.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4';

const TABLES = ['students', 'batches', 'fees', 'att', 'tests', 'marks', 'enquiries', 'homework', 'notices', 'salary', 'staff'];

const camel = (k: string) => k.replace(/_([a-z])/g, (_m, c) => c.toUpperCase());
function fromDb(row: Record<string, any>) {
  const out: Record<string, any> = { id: row.id };
  for (const k of Object.keys(row)) {
    if (k === 'id') continue;
    if (k === 'extra') { Object.assign(out, row.extra || {}); continue; }
    if (row[k] !== null && row[k] !== undefined) out[camel(k)] = row[k];
  }
  return out;
}
function same(a: string, b: string) {          // constant-time compare
  if (a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}

Deno.serve(async (req) => {
  const secret = Deno.env.get('BACKUP_KEY') || '';
  const got = req.headers.get('x-backup-key') || '';
  if (secret.length < 24 || !same(got, secret)) return new Response('Forbidden', { status: 403 });

  const sb = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  // ?done=1 : the Drive copy was saved, so record the date (the app uses it for its "last backup" reminder)
  if (new URL(req.url).searchParams.get('done') === '1') {
    const today = new Date(Date.now() + 5.75 * 3600e3).toISOString().slice(0, 10);   // Nepal time
    const { error } = await sb.from('settings').update({ last_backup: today }).eq('id', 'main');
    return new Response(error ? error.message : 'ok', { status: error ? 500 : 200 });
  }

  const data: Record<string, unknown[]> = {};
  for (const t of TABLES) {
    const all: any[] = [];
    for (let from = 0; ; from += 1000) {
      const { data: rows, error } = await sb.from(t).select('*').order('id').range(from, from + 999);
      if (error) return new Response(`Could not read ${t}: ${error.message}`, { status: 500 });
      all.push(...(rows || []));
      if (!rows || rows.length < 1000) break;
    }
    data[t] = all.map(fromDb);
  }
  const { data: st } = await sb.from('settings').select('centre, esewa').eq('id', 'main').maybeSingle();
  data.settings = [{ id: 'main', centre: st?.centre || '', esewa: st?.esewa || '' }];

  const body = JSON.stringify({ app: 'TUITIONAPP', version: 2, created: new Date().toISOString(), data });
  return new Response(body, { headers: { 'Content-Type': 'application/json' } });
});
