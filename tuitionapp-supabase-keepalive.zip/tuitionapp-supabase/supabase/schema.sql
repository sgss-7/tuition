-- TUITIONAPP: Supabase (Postgres) schema, translated from firestore.rules.
-- Run once in Supabase Dashboard > SQL Editor.
-- Roles: owner (admin) = everything; teacher = students, attendance, tests, marks, homework,
-- and their own staff/salary rows. No fees, settings, enquiries or owner screens for teachers.
-- Ids stay text so existing Firestore document ids (s123, t456, 2083-07_... ) import unchanged.

------------------------------------------------------------------ profiles (was /users)
create table public.profiles (
  id        uuid primary key references auth.users(id) on delete cascade,
  role      text not null check (role in ('owner','teacher')),
  name      text,
  email     text,
  phone     text,
  staff_id  text                      -- teachers only: link to staff.id
);

------------------------------------------------------------------ app tables
create table public.public_info (      -- centre name, readable before sign-in
  id text primary key default 'info' check (id = 'info'),
  centre text, created bigint
);

create table public.settings (
  id text primary key default 'main' check (id = 'main'),
  centre text, esewa text default '', last_backup text
);

create table public.staff (
  id text primary key,
  name text not null, phone text, created text,
  login boolean default false,
  avail text default 'any',
  pay_type text default 'monthly' check (pay_type in ('monthly','shift')),
  pay numeric default 0,
  sample boolean
);

create table public.batches (
  id text primary key,
  name text not null, timing text, fee numeric default 0,
  shift text default 'morning',
  teacher_id text references public.staff(id) on delete set null,
  sample boolean
);

create table public.students (
  id text primary key,
  name text not null, cls text,
  batch_id text references public.batches(id) on delete set null,
  parent text, whatsapp text,
  disc numeric default 0,
  optout boolean default false,
  archived boolean default false,
  sample boolean
);

create table public.fees (
  id text primary key,                         -- '<studentId>_<BS month>'
  student_id text not null references public.students(id) on delete cascade,
  month text not null,                         -- BS 'YYYY-MM'
  amount numeric not null,
  part numeric default 0,
  due text, paid_on text, rcpt text,
  sample boolean
);
create index on public.fees (student_id);
create index on public.fees (month);

create table public.att (                      -- one row per student per BS month
  id text primary key,                         -- '<studentId>_<BS month>'
  student_id text not null references public.students(id) on delete cascade,
  month text not null,
  days jsonb not null default '{}'::jsonb,     -- {"2026-10-24":"P"}
  sample boolean
);
create index on public.att (month);

create table public.tests (
  id text primary key,
  title text, date text, max numeric, avg numeric, count int,
  sample boolean
);
create index on public.tests (date);

create table public.marks (
  id text primary key,                         -- '<testId>_<studentId>'
  test_id text not null references public.tests(id) on delete cascade,
  student_id text not null references public.students(id) on delete cascade,
  m numeric, rank int, n int, date text,
  sample boolean
);
create index on public.marks (date);

create table public.homework (
  id text primary key,
  batch_id text references public.batches(id) on delete cascade,
  text text, due text, sample boolean
);

create table public.notices (
  id text primary key,
  text text, kind text, date text, created text
);

create table public.enquiries (
  id text primary key,
  name text, phone text, referred_by text, date text,
  status text default 'new' check (status in ('new','contacted','joined')),
  sample boolean
);

create table public.salary (
  id text primary key,                         -- '<staffId>_<BS month>'
  staff_id text not null references public.staff(id) on delete cascade,
  month text, amount numeric, shifts int, paid_on text
);

create table public.claims (                   -- payment claims (owner only)
  id text primary key,
  fee_id text references public.fees(id) on delete cascade,
  status text default 'pending', decided text,
  extra jsonb default '{}'::jsonb
);

create table public.logs (
  id text primary key,
  t bigint not null, who text,
  text text not null check (char_length(text) <= 300)
);

-- phone -> private login email (was /loginmap). Never listable; looked up through login_email().
create table public.loginmap (
  key text primary key,                        -- '<role>_<phone>'
  email text not null,
  uid uuid references auth.users(id) on delete cascade
);

------------------------------------------------------------------ helper functions
create or replace function public.my_role() returns text
language sql stable security definer set search_path = public as
$$ select role from public.profiles where id = auth.uid() $$;

create or replace function public.my_staff_id() returns text
language sql stable security definer set search_path = public as
$$ select staff_id from public.profiles where id = auth.uid() $$;

create or replace function public.is_owner() returns boolean
language sql stable as $$ select coalesce(public.my_role() = 'owner', false) $$;

create or replace function public.is_staff() returns boolean
language sql stable as $$ select coalesce(public.my_role() in ('owner','teacher'), false) $$;

create or replace function public.has_user() returns boolean
language sql stable as $$ select public.my_role() is not null $$;

-- sign-in screen: which email belongs to this phone number (single lookup, no listing)
create or replace function public.login_email(p_role text, p_phone text) returns text
language sql stable security definer set search_path = public as
$$ select email from public.loginmap where key = p_role || '_' || p_phone $$;
grant execute on function public.login_email(text, text) to anon, authenticated;

-- first run: the very first signed-in person becomes owner (works only once)
create or replace function public.setup_owner(p_centre text, p_name text default 'Admin') returns void
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  if exists (select 1 from public.public_info) then raise exception 'already set up'; end if;
  insert into public.profiles(id, role, name, email)
    values (auth.uid(), 'owner', p_name, (select email from auth.users where id = auth.uid()));
  insert into public.public_info(id, centre, created) values ('info', p_centre, (extract(epoch from now())*1000)::bigint);
  insert into public.settings(id, centre, esewa) values ('main', p_centre, '');
end $$;
grant execute on function public.setup_owner(text, text) to authenticated;

-- teachers may change only shift, timing and teacher_id of an existing batch (never the fee)
create or replace function public.batches_teacher_guard() returns trigger
language plpgsql as $$
begin
  if public.my_role() = 'teacher' then
    if (new.id, new.name, new.fee, new.sample) is distinct from (old.id, old.name, old.fee, old.sample) then
      raise exception 'teachers may only change shift, timing and teacher';
    end if;
  end if;
  return new;
end $$;
create trigger batches_teacher_guard before update on public.batches
  for each row execute function public.batches_teacher_guard();

------------------------------------------------------------------ row level security
do $$ declare t text; begin
  foreach t in array array['profiles','public_info','settings','staff','batches','students','fees','att',
    'tests','marks','homework','notices','enquiries','salary','claims','logs','loginmap']
  loop execute format('alter table public.%I enable row level security', t); end loop;
end $$;

-- profiles: read own, owner reads/writes all
create policy profiles_read   on public.profiles for select to authenticated using (id = auth.uid() or public.is_owner());
create policy profiles_write  on public.profiles for all    to authenticated using (public.is_owner()) with check (public.is_owner());

-- public_info: anyone can read; owner updates (creation goes through setup_owner)
create policy info_read   on public.public_info for select to anon, authenticated using (true);
create policy info_update on public.public_info for update to authenticated using (public.is_owner());

-- settings
create policy settings_read  on public.settings for select to authenticated using (public.has_user());
create policy settings_write on public.settings for all    to authenticated using (public.is_owner()) with check (public.is_owner());

-- students: staff read, owner write
create policy students_read  on public.students for select to authenticated using (public.is_staff());
create policy students_write on public.students for all    to authenticated using (public.is_owner()) with check (public.is_owner());

-- batches: any user reads, owner writes, teacher updates (column guard in trigger)
create policy batches_read    on public.batches for select to authenticated using (public.has_user());
create policy batches_write   on public.batches for all    to authenticated using (public.is_owner()) with check (public.is_owner());
create policy batches_teacher on public.batches for update to authenticated
  using (public.my_role() = 'teacher') with check (public.my_role() = 'teacher');

-- owner only
create policy fees_all      on public.fees      for all to authenticated using (public.is_owner()) with check (public.is_owner());
create policy enquiries_all on public.enquiries for all to authenticated using (public.is_owner()) with check (public.is_owner());
create policy claims_all    on public.claims    for all to authenticated using (public.is_owner()) with check (public.is_owner());

-- staff: attendance and marks
create policy att_all   on public.att   for all to authenticated using (public.is_staff()) with check (public.is_staff());
create policy marks_all on public.marks for all to authenticated using (public.is_staff()) with check (public.is_staff());

-- tests and homework: any user reads, staff writes
create policy tests_read  on public.tests    for select to authenticated using (public.has_user());
create policy tests_write on public.tests    for all    to authenticated using (public.is_staff()) with check (public.is_staff());
create policy hw_read     on public.homework for select to authenticated using (public.has_user());
create policy hw_write    on public.homework for all    to authenticated using (public.is_staff()) with check (public.is_staff());

-- notices: any user reads, owner writes
create policy notices_read  on public.notices for select to authenticated using (public.has_user());
create policy notices_write on public.notices for all    to authenticated using (public.is_owner()) with check (public.is_owner());

-- teacher sees only their own staff row and pay
create policy staff_read   on public.staff for select to authenticated using (public.is_owner() or id = public.my_staff_id());
create policy staff_write  on public.staff for all    to authenticated using (public.is_owner()) with check (public.is_owner());
create policy salary_read  on public.salary for select to authenticated using (public.is_owner() or staff_id = public.my_staff_id());
create policy salary_write on public.salary for all    to authenticated using (public.is_owner()) with check (public.is_owner());

-- logs: owner reads/deletes, any user may append a short entry
create policy logs_read   on public.logs for select to authenticated using (public.is_owner());
create policy logs_insert on public.logs for insert to authenticated with check (public.has_user());
create policy logs_delete on public.logs for delete to authenticated using (public.is_owner());

-- loginmap: owner only (the sign-in screen uses login_email())
create policy loginmap_owner on public.loginmap for all to authenticated using (public.is_owner()) with check (public.is_owner());

------------------------------------------------------------------ realtime (replaces Firestore listeners)
alter publication supabase_realtime add table
  public.students, public.batches, public.fees, public.att, public.tests, public.marks,
  public.homework, public.notices, public.enquiries, public.staff, public.salary, public.settings, public.claims;

------------------------------------------------------------------ migration support
-- Any field the app stores that has no column of its own is kept here, so nothing is lost.
do $$ declare t text; begin
  foreach t in array array['settings','staff','batches','students','fees','att','tests','marks','homework',
    'notices','enquiries','salary','claims','logs']
  loop execute format('alter table public.%I add column if not exists extra jsonb not null default ''{}''::jsonb', t); end loop;
end $$;

-- Attendance days are merged on the server so two teachers marking the same month never overwrite each other.
-- security invoker: row level security (is_staff) still applies.
create or replace function public.att_set(p_id text, p_student text, p_month text, p_days jsonb) returns void
language sql as $$
  insert into public.att(id, student_id, month, days) values (p_id, p_student, p_month, p_days)
  on conflict (id) do update set days = public.att.days || excluded.days
$$;

create or replace function public.att_bulk(p_rows jsonb) returns void
language sql as $$
  insert into public.att(id, student_id, month, days)
  select r->>'id', r->>'student_id', r->>'month', r->'days' from jsonb_array_elements(p_rows) r
  on conflict (id) do update set days = public.att.days || excluded.days
$$;
grant execute on function public.att_set(text,text,text,jsonb), public.att_bulk(jsonb) to authenticated;
