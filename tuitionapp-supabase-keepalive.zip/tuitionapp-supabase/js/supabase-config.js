/* Paste your Supabase project settings here.
   Supabase Dashboard > Project Settings > API: "Project URL" and the "anon public" key.
   Both are safe to publish. Your data is protected by the row level security in supabase/schema.sql.
   NEVER put the service_role key in this file. */
export const supabaseConfig = {
  url: "https://kgnmcomnebnuacmeydpf.supabase.co",        // for example https://abcdxyz.supabase.co
  anonKey: "sb_publishable_AkJYfdcDervAWv8CEvPM6Q_1AxKgqBq"
};
