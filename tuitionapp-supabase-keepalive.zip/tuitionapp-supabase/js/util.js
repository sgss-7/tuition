/* Pure helpers: dates (English + Bikram Sambat), formatting, ids, phone numbers, PDF maker. No Firebase here. */
export const NL = '\n';
export function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
export function p2(n) { return ('0' + n).slice(-2); }
export function iso(d) { return d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate()); }
export function parse(s) { return new Date(s + 'T00:00:00'); }
export const today = new Date(); today.setHours(0, 0, 0, 0);
export const TODAY = iso(today);
export function addDays(d, n) { var x = new Date(d); x.setDate(x.getDate() + n); return x; }
export function daysBetween(a, b) { return Math.round((a - b) / 864e5); }

/* Bikram Sambat (BS) calendar. Month lengths per year; BS 2080-01-01 = 14 Apr 2023. */
export const BSD = { 2080: [31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 30], 2081: [31, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31], 2082: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30], 2083: [31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30], 2084: [31, 31, 32, 31, 31, 30, 30, 30, 29, 30, 30, 30], 2085: [31, 32, 31, 32, 30, 31, 30, 30, 29, 30, 30, 30], 2086: [30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 30, 30], 2087: [31, 31, 32, 31, 31, 31, 30, 30, 29, 30, 30, 30], 2088: [30, 31, 32, 32, 30, 31, 30, 30, 29, 30, 30, 30], 2089: [30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 30, 30], 2090: [30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 30, 30] };
export const BSM = ['Baisakh', 'Jestha', 'Ashadh', 'Shrawan', 'Bhadra', 'Ashwin', 'Kartik', 'Mangsir', 'Poush', 'Magh', 'Falgun', 'Chaitra'];
export const BSN = ['बैशाख', 'जेठ', 'असार', 'श्रावण', 'भदौ', 'असोज', 'कात्तिक', 'मंसिर', 'पौष', 'माघ', 'फागुन', 'चैत'];
const BS0 = new Date(2023, 3, 14);
function sumArr(a) { return a.reduce(function (x, y) { return x + y; }, 0); }
export function ne(x) { return String(x).replace(/\d/g, function (c) { return '०१२३४५६७८९'.charAt(+c); }); }
export function toBS(d) { var n = Math.round((d - BS0) / 864e5); if (n < 0) return null; var y = 2080; while (BSD[y]) { var len = sumArr(BSD[y]); if (n < len) break; n -= len; y++; } if (!BSD[y]) return null; var m = 0; while (n >= BSD[y][m]) { n -= BSD[y][m]; m++; } return { y: y, m: m, d: n + 1 }; }
export function bsToAD(y, m, d) { var n = 0, k; for (k = 2080; k < y; k++) n += sumArr(BSD[k]); for (k = 0; k < m; k++) n += BSD[y][k]; n += d - 1; return addDays(BS0, n); }
export function monthKey(d) { var b = toBS(d); return b ? b.y + '-' + p2(b.m + 1) : iso(d).slice(0, 7); }
export function prevKey(key) { var p = key.split('-'), y = +p[0], m = +p[1]; return m > 1 ? y + '-' + p2(m - 1) : (y - 1) + '-12'; }
export function keyDay(key, d) { var p = key.split('-'), y = +p[0], m = +p[1] - 1; return BSD[y] ? iso(bsToAD(y, m, d)) : key + '-' + p2(d); }
export function bsIso(s) { var b = toBS(parse(s)); return b ? b.y + '-' + p2(b.m + 1) + '-' + p2(b.d) : s; }
export function parseBS(s) { var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s).trim()); if (!m) return null; var y = +m[1], mo = +m[2] - 1, d = +m[3]; if (!BSD[y] || mo < 0 || mo > 11 || d < 1 || d > BSD[y][mo]) return null; return iso(bsToAD(y, mo, d)); }
export function monthLabel(m) { var p = String(m).split('-'); return BSM[+p[1] - 1] + ' ' + p[0]; }
export function monthLabelNe(m) { var p = String(m).split('-'); return BSN[+p[1] - 1] + ' ' + ne(p[0]); }
export function dayLabel(s) { var d = parse(s), b = toBS(d); return b ? d.toLocaleDateString('en-IN', { weekday: 'short' }) + ', ' + b.d + ' ' + BSM[b.m] + ' ' + b.y : s; }
export function shortDay(s) { var b = toBS(parse(s)); return b ? b.d + ' ' + BSM[b.m] : s; }
export function shortDayNe(s) { var b = toBS(parse(s)); return b ? ne(b.d) + ' ' + BSN[b.m] : s; }
export function dayLabelNe(s) { var b = toBS(parse(s)); return b ? ne(b.d) + ' ' + BSN[b.m] + ' ' + ne(b.y) : s; }

/* Money, ids, phones */
export function rs(n) { return 'Rs ' + Number(n || 0).toLocaleString('en-IN'); }
export function rsNe(n) { return 'रु ' + ne(Number(n || 0).toLocaleString('en-IN')); }
export function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
export function byName(a, b) { return String(a.name).localeCompare(String(b.name)); }
export function digits(s) { return String(s || '').replace(/\D/g, ''); }
export function last10(x) { return digits(x).slice(-10); }
export function digits10(x) { var d = digits(x); if (d.length === 13 && d.indexOf('977') === 0) d = d.slice(3); return d; }
export function validPhone(x) { return digits10(x).length === 10; }
export function rand(n) { var a = new Uint8Array(n || 12); crypto.getRandomValues(a); return Array.from(a).map(function (b) { return ('0' + b.toString(16)).slice(-2); }).join(''); }

/* Minimal one-page PDF that holds one JPEG picture. Page size in points (A4 = 595.28 x 841.89, A5 = 419.53 x 595.28). */
export function jpegPdf(jpeg, iw, ih, pw, ph) {
  var enc = new TextEncoder(), parts = [], len = 0, offs = [];
  function add(x) { var b = typeof x === 'string' ? enc.encode(x) : x; parts.push(b); len += b.length; }
  function obj(n, body) { offs[n] = len; add(n + ' 0 obj\n'); add(body); add('\nendobj\n'); }
  add('%PDF-1.4\n');
  obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
  obj(2, '<< /Type /Pages /Kids [3 0 R] /Count 1 >>');
  obj(3, '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + pw + ' ' + ph + '] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>');
  offs[4] = len;
  add('4 0 obj\n<< /Type /XObject /Subtype /Image /Width ' + iw + ' /Height ' + ih + ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ' + jpeg.length + ' >>\nstream\n');
  add(jpeg); add('\nendstream\nendobj\n');
  var content = 'q ' + pw + ' 0 0 ' + ph + ' 0 0 cm /Im0 Do Q';
  obj(5, '<< /Length ' + content.length + ' >>\nstream\n' + content + '\nendstream');
  var xref = len, x = 'xref\n0 6\n0000000000 65535 f \n';
  for (var i = 1; i <= 5; i++) x += String(offs[i]).padStart(10, '0') + ' 00000 n \n';
  add(x); add('trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n' + xref + '\n%%EOF');
  var out = new Uint8Array(len), pos = 0;
  parts.forEach(function (b) { out.set(b, pos); pos += b.length; });
  return out;
}
export function dataUrlBytes(url) { var b = atob(url.split(',')[1]), u = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; }
