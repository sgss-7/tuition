/* Pure mapping between the app's records (camelCase, one object per document) and Postgres rows (snake_case).
   Any field that has no column is kept in the table's `extra` jsonb column, so nothing is ever lost.
   Used by store.js (browser) and tools/import-backup.mjs (Node). No browser or network code here. */

export const COLS = {
  settings: ['centre', 'esewa', 'last_backup'],
  staff: ['name', 'phone', 'created', 'login', 'avail', 'pay_type', 'pay', 'sample'],
  batches: ['name', 'timing', 'fee', 'shift', 'teacher_id', 'sample'],
  students: ['name', 'cls', 'batch_id', 'parent', 'whatsapp', 'disc', 'optout', 'archived', 'sample'],
  fees: ['student_id', 'month', 'amount', 'part', 'due', 'paid_on', 'rcpt', 'sample'],
  att: ['student_id', 'month', 'days', 'sample'],
  tests: ['title', 'date', 'max', 'avg', 'count', 'sample'],
  marks: ['test_id', 'student_id', 'm', 'rank', 'n', 'date', 'sample'],
  homework: ['batch_id', 'text', 'due', 'sample'],
  notices: ['text', 'kind', 'date', 'created'],
  enquiries: ['name', 'phone', 'referred_by', 'date', 'status', 'sample'],
  salary: ['staff_id', 'month', 'amount', 'shifts', 'paid_on'],
  claims: ['fee_id', 'status', 'decided'],
  logs: ['t', 'who', 'text']
};
export const TABLES = Object.keys(COLS);

/* columns that point at another table: the app uses '' for "none", Postgres needs null */
const FK = { teacher_id: 1, batch_id: 1, student_id: 1, test_id: 1, staff_id: 1, fee_id: 1 };
/* not-null columns that need a value when the record leaves them out */
const FILL = { att: { days: {} } };

/* parents before children, so restores and imports never hit a missing reference */
export const ORDER = ['settings', 'staff', 'batches', 'students', 'tests', 'fees', 'att', 'marks', 'enquiries', 'homework', 'notices', 'salary', 'claims', 'logs'];

export function snake(k) { return String(k).replace(/[A-Z]/g, function (c) { return '_' + c.toLowerCase(); }); }
export function camel(k) { return String(k).replace(/_([a-z])/g, function (_, c) { return c.toUpperCase(); }); }

export function toDb(table, id, data) {
  var cols = COLS[table], row = { id: id }, extra = {}, seen = {};
  Object.keys(data || {}).forEach(function (k) {
    if (k === 'id' || data[k] === undefined) return;
    var s = snake(k), v = data[k];
    if (cols.indexOf(s) >= 0) { if (FK[s] && v === '') v = null; row[s] = v; seen[s] = 1; }
    else extra[k] = v;
  });
  cols.forEach(function (c) { if (!seen[c]) row[c] = FILL[table] && c in FILL[table] ? FILL[table][c] : null; });
  row.extra = extra;
  return row;
}

/* null means "field not set", which is how the app has always read missing values */
export function fromDb(row) {
  var out = { id: row.id };
  Object.keys(row).forEach(function (k) {
    if (k === 'id') return;
    if (k === 'extra') { var e = row.extra || {}; Object.keys(e).forEach(function (x) { out[x] = e[x]; }); return; }
    if (row[k] !== null && row[k] !== undefined) out[camel(k)] = row[k];
  });
  return out;
}
