/* Supabase wiring: sign-in, live data (realtime), saving, and teacher logins.
   Everything the screens read lives in S (one array per collection).
   The exported names match the old Firebase version, so main.js only needed small edits. */
import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/+esm';
import { supabaseConfig } from './supabase-config.js';
import { today, iso, addDays, monthKey, prevKey, parse, uid } from './util.js';
import { toDb, fromDb, ORDER } from './dbmap.js';

export { uid };
export const configured = !/PASTE/.test(String(supabaseConfig.url) + String(supabaseConfig.anonKey));
export const COLL = ['students', 'batches', 'fees', 'att', 'tests', 'marks', 'enquiries', 'homework', 'settings', 'notices', 'staff', 'logs', 'claims', 'salary'];

/* ---------- data held in memory ---------- */
export const S = {};
export const ALLSTU = [];
COLL.forEach(function (c) { if (c !== 'students') S[c] = []; });
Object.defineProperty(S, 'students', { enumerable: true, get: function () { return ALLSTU.filter(function (x) { return !x.archived; }); } });
export function rows(c) { return c === 'students' ? ALLSTU : S[c]; }
export const IDX = { att: {}, mk: {} };           // att: {studentId:{date:'P'|'A'}}   mk: {testId_studentId: marksRow}
export const state = { waiting: 0, ready: false };
export const hooks = { audit: function () { }, fail: function () { }, change: function () { }, denied: function () { } };

export function reindex() {
  var a = {}, m = {};
  S.att.forEach(function (r) { var d = r.days || {}; var t = a[r.studentId] || (a[r.studentId] = {}); Object.keys(d).forEach(function (k) { t[k] = d[k]; }); });
  S.marks.forEach(function (r) { m[r.testId + '_' + r.studentId] = r; });
  IDX.att = a; IDX.mk = m;
}
export function attDay(sid, date) { var t = IDX.att[sid]; return t ? t[date] : undefined; }
export function markOf(tid, sid) { return IDX.mk[tid + '_' + sid]; }
export function strip(o) { var r = Object.assign({}, o); delete r.id; return r; }

/* ---------- Supabase init ---------- */
export let sb;
var email0 = '';
export function initFirebase() {   // name kept so main.js stays simple; it starts Supabase
  if (!configured) return false;
  sb = createClient(supabaseConfig.url, supabaseConfig.anonKey, {
    auth: { persistSession: true, autoRefreshToken: true, storage: window.sessionStorage }   // closing the tab signs out, like before
  });
  return true;
}

/* Supabase errors -> the codes main.js already understands */
function wrap(e) {
  if (!e) return e;
  var m = String(e.message || ''), c = String(e.code || ''), st = e.status, o = new Error(m);
  o.status = st;
  if (c === 'user_already_exists' || /already registered/i.test(m)) o.code = 'auth/email-already-in-use';
  else if (c === 'weak_password') o.code = 'auth/weak-password';
  else if (c === 'invalid_credentials' || /invalid login credentials/i.test(m)) o.code = 'auth/invalid-credential';
  else if (c === 'user_not_found') o.code = 'auth/user-not-found';
  else if (c === 'email_address_invalid' || c === 'validation_failed') o.code = 'auth/invalid-email';
  else if (c === 'over_request_rate_limit' || c === 'over_email_send_rate_limit' || st === 429) o.code = 'auth/too-many-requests';
  else if (c === '42501' || st === 401 || st === 403 || /row-level security|permission denied|not allowed/i.test(m)) o.code = 'permission-denied';
  else if (/failed to fetch|network|load failed/i.test(m)) o.code = 'auth/network-request-failed';
  else o.code = c || 'unknown';
  return o;
}
function ok(res) { if (res && res.error) throw wrap(res.error); return res; }
function fail(e) { return hooks.fail(wrap(e)); }

/* ---------- auth ---------- */
var lastUid = null;
export function watchAuth(cb) {
  var sub = sb.auth.onAuthStateChange(function (ev, session) {
    var u = session && session.user ? session.user : null;
    if (u) email0 = u.email || '';
    // token refreshes and tab re-focus also fire events; only react to real changes of who is signed in
    var id = u ? u.id : null;
    if (ev === 'INITIAL_SESSION' || id !== lastUid) { lastUid = id; cb(u ? { uid: u.id, email: u.email } : null); }
  });
  return function () { sub.data.subscription.unsubscribe(); };
}
export function signIn(email, pw) { return sb.auth.signInWithPassword({ email: email, password: pw }).then(ok).catch(function (e) { throw wrap(e); }); }
export function logoutNow() { return sb.auth.signOut(); }
export function resetPassword(email) {
  return sb.auth.resetPasswordForEmail(email, { redirectTo: location.origin + location.pathname.replace(/[^/]*$/, '') + 'reset.html' }).then(ok).catch(function (e) { throw wrap(e); });
}
export function reauth(pw) { return sb.auth.signInWithPassword({ email: email0, password: pw }).then(ok).catch(function (e) { throw wrap(e); }); }
export function changePassword(oldPw, newPw) {
  return reauth(oldPw).then(function () { return sb.auth.updateUser({ password: newPw }); }).then(ok).catch(function (e) { throw wrap(e); });
}
export function currentEmail() { return email0; }

function snap(row) { return { exists: function () { return !!row; }, data: function () { return row ? fromDb(Object.assign({ id: row.id }, row)) : undefined; } }; }
export function getUserDoc(u) {
  return sb.from('profiles').select('*').eq('id', u).maybeSingle().then(ok).then(function (r) { return snap(r.data); });
}
export function getInfo() {
  return sb.from('public_info').select('*').eq('id', 'info').maybeSingle().then(ok).then(function (r) { return snap(r.data); });
}
export function setInfo(centre) { return sb.from('public_info').update({ centre: centre }).eq('id', 'info').then(ok); }

/* first run: the very first person to set up becomes the admin (setup_owner allows this only once) */
export function createOwner(email, pw, centre) {
  return sb.auth.signUp({ email: email, password: pw }).then(function (r) {
    if (r.error) {
      var w = wrap(r.error);
      if (w.code === 'auth/email-already-in-use') return sb.auth.signInWithPassword({ email: email, password: pw }).then(ok);
      throw w;
    }
    if (!r.data.session) throw wrap({ message: 'Email confirmation is on. Turn it off in Supabase: Authentication > Providers > Email.', code: 'unknown' });
    return r;
  }).then(function (r) {
    var user = r.data.user || r.data.session.user; email0 = user.email || email;
    return sb.rpc('setup_owner', { p_centre: centre, p_name: 'Admin' }).then(ok).then(function () { return { uid: user.id, email: email }; });
  }).catch(function (e) { throw e && e.code ? e : wrap(e); });
}

/* ---------- teacher logins ----------
   Teachers sign in with a phone number, so each gets a private made-up email. Creating or deleting an
   auth user needs the service key, so it runs in the manage-login Edge Function (owner only). */
export function loginKey(role, phone) { return role + '_' + phone; }
export function getLoginEmail(role, phone) {
  return sb.rpc('login_email', { p_role: role, p_phone: phone }).then(ok).then(function (r) { return r.data || null; });
}
export function loginExists(role, phone) { return getLoginEmail(role, phone).then(function (e) { return !!e; }); }
function callLogin(body) {
  return sb.functions.invoke('manage-login', { body: body }).then(function (r) {
    if (r.error) {
      var ctx = r.error.context;
      if (ctx && typeof ctx.json === 'function') return ctx.json().then(function (j) { throw wrap({ message: (j && j.error) || r.error.message, code: j && j.code, status: ctx.status }); }, function () { throw wrap(r.error); });
      throw wrap(r.error);
    }
    return r.data;
  });
}
export function makeLogin(role, phone, name, pw, extra) {
  return callLogin({ action: 'make', role: role, phone: phone, name: name, password: pw, staffId: extra && extra.staffId });
}
export function dropLogin(role, phone) { return callLogin({ action: 'drop', role: role, phone: phone }); }

/* ---------- local change helpers ---------- */
export function local(c, id, data) {
  var R = rows(c), row = Object.assign({ id: id }, data), i = R.findIndex(function (x) { return x.id === id; });
  if (i >= 0) R[i] = row; else R.push(row);
  if (c === 'att' || c === 'marks') reindex();
}
export function unlocal(c, id) {
  var R = rows(c), i = R.findIndex(function (x) { return x.id === id; });
  if (i >= 0) R.splice(i, 1);
  if (c === 'att' || c === 'marks') reindex();
}
export function get(c, id) { return rows(c).filter(function (x) { return x.id === id; })[0]; }
function clean(o) { var r = {}; Object.keys(o).forEach(function (k) { if (o[k] !== undefined) r[k] = o[k]; }); return r; }
export function put(c, id, data) {
  data = clean(data); var existed = !!get(c, id); local(c, id, data); hooks.audit(c, id, 'saved', data);
  var row = toDb(c, id, data);
  /* a plain update when the record already exists: teachers may update a batch's shift but are not allowed to insert batches */
  var w = existed
    ? (function () { var r = Object.assign({}, row); delete r.id; return sb.from(c).update(r).eq('id', id).select('id').then(ok).then(function (res) { return res.data && res.data.length ? res : sb.from(c).upsert(row, { onConflict: 'id' }).then(ok); }); })()
    : sb.from(c).upsert(row, { onConflict: 'id' }).then(ok);
  return w.catch(fail);
}
export function patch(c, id, fields) { var cur = get(c, id) || {}; return put(c, id, Object.assign(strip(cur), fields)); }
export function remove(c, id) {
  var pre = get(c, id); hooks.audit(c, id, 'deleted', pre || {});
  unlocal(c, id); return sb.from(c).delete().eq('id', id).then(ok).catch(fail);
}
/* delete on the server only (the caller already updated the screen) */
export function removeRemote(c, id) { return sb.from(c).delete().eq('id', id).then(ok).catch(function () { }); }

/* attendance: one row per student per BS month, days stored as {'2026-10-24':'P'}. The functions merge days on the server. */
export function attId(sid, date) { return sid + '_' + monthKey(parse(date)); }
function attLocal(sid, date, v) {
  var id = attId(sid, date), cur = get('att', id), days = Object.assign({}, cur ? cur.days : {});
  days[date] = v; local('att', id, { studentId: sid, month: monthKey(parse(date)), days: days });
}
export function setAtt(sid, date, v) {
  attLocal(sid, date, v);
  var days = {}; days[date] = v;
  return sb.rpc('att_set', { p_id: attId(sid, date), p_student: sid, p_month: monthKey(parse(date)), p_days: days }).then(ok).catch(fail);
}
export function bulkAtt(sids, date, v) {
  var days = {}; days[date] = v;
  var list = sids.map(function (sid) { attLocal(sid, date, v); return { id: attId(sid, date), student_id: sid, month: monthKey(parse(date)), days: days }; });
  return sb.rpc('att_bulk', { p_rows: list }).then(ok).catch(fail);
}
/* older months are not kept open; fetch one on demand (used by the monthly report) */
var loadedMonths = {};
export function ensureAttMonth(m) {
  if (loadedMonths[m] || !sb) return Promise.resolve();
  loadedMonths[m] = 1;
  return fetchPaged(function () { return sb.from('att').select('*').eq('month', m); }).then(function (list) {
    list.forEach(function (r) { if (!get('att', r.id)) local('att', r.id, strip(fromDb(r))); });
    hooks.change();
  }).catch(function () { delete loadedMonths[m]; });
}

/* PostgREST returns at most 1000 rows per request, so read big tables in pages */
function fetchPaged(build) {
  var all = [], size = 1000;
  function page(from) {
    return build().order('id').range(from, from + size - 1).then(ok).then(function (r) {
      all = all.concat(r.data || []);
      return (r.data || []).length === size ? page(from + size) : all;
    });
  }
  return page(0);
}

/* write many records in chunks of 400: deletes first, then saves, parents before children */
export function bulkWrite(jobs) {
  var dels = {}, sets = {};
  jobs.forEach(function (j) {
    if (j[0] === 'del') (dels[j[1]] = dels[j[1]] || []).push(j[2]);
    else (sets[j[1]] = sets[j[1]] || []).push(toDb(j[1], j[2], clean(j[3])));
  });
  var steps = [];
  ORDER.slice().reverse().forEach(function (t) {
    var ids = dels[t] || [];
    for (var i = 0; i < ids.length; i += 200) steps.push((function (ch) { return function () { return sb.from(t).delete().in('id', ch).then(ok); }; })(ids.slice(i, i + 200)));
  });
  ORDER.forEach(function (t) {
    var rs = sets[t] || [];
    for (var i = 0; i < rs.length; i += 400) steps.push((function (ch) { return function () { return sb.from(t).upsert(ch, { onConflict: 'id' }).then(ok); }; })(rs.slice(i, i + 400)));
  });
  return steps.reduce(function (p, f) { return p.then(f); }, Promise.resolve()).catch(function (e) { throw wrap(e); });
}

/* ---------- live data ---------- */
var chans = [];
function first() { if (state.waiting > 0) { state.waiting--; if (state.waiting === 0) { state.ready = true; hooks.change(); } } }
function put1(c, row) {
  var R = rows(c), i = R.findIndex(function (x) { return x.id === row.id; });
  if (i >= 0) R[i] = row; else R.push(row);
}
/* c: collection. build(): the initial query. keep(row): same filter applied to live changes. filter: realtime filter string. */
function listen(c, build, keep, filter) {
  state.waiting++; var done = false;
  function fin() { if (!done) { done = true; first(); } else hooks.change(); }
  var cfg = { event: '*', schema: 'public', table: c }; if (filter) cfg.filter = filter;
  var ch = sb.channel('rt-' + c + '-' + uid()).on('postgres_changes', cfg, function (p) {
    if (p.eventType === 'DELETE') { var id = p.old && p.old.id; var R = rows(c), i = R.findIndex(function (x) { return x.id === id; }); if (i >= 0) R.splice(i, 1); }
    else if (!keep || keep(p.new)) put1(c, fromDb(p.new));
    else { var R2 = rows(c), j = R2.findIndex(function (x) { return x.id === p.new.id; }); if (j >= 0) R2.splice(j, 1); }
    if (c === 'att' || c === 'marks') reindex();
    hooks.change();
  }).subscribe();
  chans.push(ch);
  build().then(ok).then(function (r) {
    (r.data || []).forEach(function (row) { put1(c, fromDb(row)); });
    if (c === 'att' || c === 'marks') reindex();
    fin();
  }).catch(function (err) { done = true; first(); hooks.denied(c, wrap(err)); });
}
function all(c) { return function () { return pq(function () { return sb.from(c).select('*'); }); }; }
function pq(build) { return fetchPaged(build).then(function (d) { return { data: d }; }); }
export function stopSession() {
  chans.forEach(function (ch) { try { sb.removeChannel(ch); } catch (e) { } }); chans = [];
  COLL.forEach(function (c) { rows(c).length = 0; });
  IDX.att = {}; IDX.mk = {}; loadedMonths = {};
  state.waiting = 0; state.ready = false;
}
export function startSession(role, ids, staffId) {
  stopSession();
  var m0 = monthKey(today), m1 = prevKey(m0), cutoff = iso(addDays(today, -120));
  loadedMonths[m0] = 1; loadedMonths[m1] = 1;
  listen('settings', all('settings'));
  listen('batches', all('batches'));
  listen('homework', function () { return sb.from('homework').select('*').order('due', { ascending: false }).limit(30).then(function (r) { return r; }); });
  listen('notices', function () { return sb.from('notices').select('*').order('created', { ascending: false }).limit(20).then(function (r) { return r; }); });
  listen('tests', function () { return pq(function () { return sb.from('tests').select('*').gte('date', cutoff); }); }, function (r) { return String(r.date) >= cutoff; });
  if (role === 'owner' || role === 'teacher') {
    listen('students', all('students'));
    listen('att', function () { return pq(function () { return sb.from('att').select('*').in('month', [m0, m1]); }); }, function (r) { return r.month === m0 || r.month === m1; });
    listen('marks', function () { return pq(function () { return sb.from('marks').select('*').gte('date', cutoff); }); }, function (r) { return String(r.date) >= cutoff; });
  }
  if (role === 'owner') {
    listen('fees', all('fees'));
    listen('enquiries', all('enquiries'));
    listen('staff', all('staff'));
    listen('salary', all('salary'));
  }
  if (role === 'teacher' && staffId) {
    listen('staff', function () { return pq(function () { return sb.from('staff').select('*').eq('id', staffId); }); }, null, 'id=eq.' + staffId);
    listen('salary', function () { return pq(function () { return sb.from('salary').select('*').eq('staff_id', staffId); }); }, null, 'staff_id=eq.' + staffId);
  }
}

/* full copy of every collection for the backup file (same format as the old Firebase backups) */
export function fetchAll(names) {
  return Promise.all(names.map(function (c) {
    return fetchPaged(function () { return sb.from(c).select('*'); }).then(function (list) { return [c, list.map(fromDb)]; });
  })).then(function (a) { var o = {}; a.forEach(function (x) { o[x[0]] = x[1]; }); return o; });
}
