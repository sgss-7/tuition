/* TUITIONAPP screens. Data comes from store.js (Supabase). Roles: admin, teacher. */
import * as U from './util.js';
import * as DB from './store.js';
const { esc, p2, iso, parse, addDays, daysBetween, today, TODAY, ne, monthKey, prevKey, keyDay, bsIso, parseBS, monthLabel, monthLabelNe, dayLabel, shortDay, shortDayNe, dayLabelNe, rs, rsNe, uid, byName, digits, last10, digits10, validPhone, NL } = U;
const { S, ALLSTU, rows, put, patch, remove, strip } = DB;

const ui = { tab: 'fees', date: TODAY, batch: 'all', testId: null, profileId: null, booted: false, session: null, info: null, ff: 'all', q: '', sq: '', repMonth: null, lrole: 'owner', sf: 'all', fatal: null, busy: false, warned: false, denied: false };
const $ = function (s) { return document.querySelector(s); };

/* ---------- small helpers ---------- */
function get(c, id) { return DB.get(c, id); }
function stu(id) { var s = DB.get('students', id); return s && !s.archived ? s : undefined; }
function stuAny(id) { return DB.get('students', id); }
function batchOf(s) { return s ? get('batches', s.batchId) : null; }
function settings() { return get('settings', 'main') || {}; }
function centre() { return settings().centre || (ui.info && ui.info.centre) || 'Your Tuition Centre'; }
function bal(f) { return Math.max(0, Number(f.amount) - Number(f.part || 0)); }
function last10s(x) { return last10(x); }
function optedOut(phone) { var n = last10(phone); return n.length >= 7 && ALLSTU.some(function (s) { return s.optout && last10(s.whatsapp) === n; }); }
function waHref(phone, text) { if (optedOut(phone)) return '#optout'; var d = digits(phone); if (d.length === 10) d = '977' + d; return 'https://wa.me/' + d + '?text=' + encodeURIComponent(text); }
function role() { return ui.session ? ui.session.role : null; }
function isTeacher() { return role() === 'teacher'; }

var IC = {
  fees: '<path d="M6 4h12M6 9h12M9 4c5 0 7 2 7 5s-2 5-7 5H6l8 7"/>',
  att: '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 9l2 2 3-3M8 16h8"/>',
  tests: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  parent: '<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/>',
  dash: '<rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/>',
  wa: '<path d="M21 12a9 9 0 0 1-13.5 7.8L3 21l1.3-4.4A9 9 0 1 1 21 12z"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  left: '<path d="M15 18l-6-6 6-6"/>',
  right: '<path d="M9 18l6-6-6-6"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  cap: '<path d="M2 9l10-5 10 5-10 5z"/><path d="M6 11v5c0 1.5 2.7 3 6 3s6-1.5 6-3v-5"/>'
};
function ic(n, sz) { sz = sz || 20; return '<svg width="' + sz + '" height="' + sz + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + IC[n] + '</svg>'; }

var tt;
function toast(m) { var t = $('#toast'); t.innerHTML = '<div class="toast">' + esc(m) + '</div>'; clearTimeout(tt); tt = setTimeout(function () { t.innerHTML = ''; }, 4200); }
function fail(e) {
  toast(e && e.code === 'permission-denied' ? 'You do not have permission to change this.' : 'Could not save. Check your connection and try again.');
}
DB.hooks.fail = fail;
DB.hooks.change = function () { schedule(); };
DB.hooks.denied = function (c, e) { console.warn('Could not read ' + c, e); if (!ui.denied) { ui.denied = true; toast('Some data could not be loaded. If this keeps happening, re-run supabase/schema.sql.'); } };
var rq = 0;
function schedule() { if (rq) return; rq = requestAnimationFrame(function () { rq = 0; render(); }); }

/* ---------- messages (WhatsApp) ---------- */
function greet(s) { return '🙏 *नमस्ते ' + (s.parent || 'अभिभावक ज्यू') + '*'; }
function foot() { return NL + NL + '🏫 _' + centre() + '_' + NL + '_यी सन्देश नचाहिएमा केन्द्रलाई जानकारी दिनुहोला।_'; }
function msgFee(s, f) {
  var d = daysBetween(today, parse(f.due));
  return greet(s) + NL + NL + '📢 *शुल्क सम्झना*' + NL + '━━━━━━━━━━━━━━' + NL +
    '👤 विद्यार्थी: *' + s.name + '*' + NL + '📅 महिना: *' + monthLabelNe(f.month) + '*' + NL + '💰 रकम: *' + rsNe(bal(f)) + '*' + NL + '⏰ म्याद: ' + shortDayNe(f.due) +
    (d > 0 ? NL + '⚠️ *' + ne(d) + ' दिन ढिला भयो*' : '') + NL + '━━━━━━━━━━━━━━' + (settings().esewa ? NL + '💚 eSewa बाट तिर्न: *' + settings().esewa + '*' + NL + '━━━━━━━━━━━━━━' : '') + NL + 'कृपया छिटो शुल्क बुझाइदिनुहोला। धन्यवाद! 🙏' + foot();
}
function msgAbsent(s, date) {
  return greet(s) + NL + NL + '📢 *अनुपस्थिति सूचना*' + NL + '━━━━━━━━━━━━━━' + NL +
    '👤 विद्यार्थी: *' + s.name + '*' + NL + '📅 मिति: ' + dayLabelNe(date) + NL + '❌ आज कक्षामा अनुपस्थित हुनुभयो' + NL + '━━━━━━━━━━━━━━' + NL + 'कृपया कारण जानकारी गराइदिनुहोला। 🙏' + foot();
}
function msgReport(s, t, row, n, delta) {
  return greet(s) + NL + NL + '📊 *साप्ताहिक परीक्षा रिपोर्ट*' + NL + '━━━━━━━━━━━━━━' + NL +
    '👤 विद्यार्थी: *' + s.name + '*' + NL + '📝 परीक्षा: ' + t.title + NL + '🎯 प्राप्ताङ्क: *' + ne(row.m) + '/' + ne(t.max) + '*' + NL + '🏆 स्थान: *' + ne(n) + ' मध्ये ' + ne(row.rank) + '*' +
    (delta ? NL + delta : '') + NL + '━━━━━━━━━━━━━━' + NL + 'निरन्तर मेहनत गर्नुहोस्, शुभकामना! 🌟' + foot();
}
function msgReceipt(s, f) {
  return greet(s) + NL + NL + '✅ *शुल्क प्राप्त भयो*' + NL + '━━━━━━━━━━━━━━' + NL +
    '👤 विद्यार्थी: *' + s.name + '*' + NL + '📅 महिना: *' + monthLabelNe(f.month) + '*' + NL + '💰 रकम: *' + rsNe(f.amount) + '*' + NL + '🧾 रसिद नं: ' + f.rcpt + NL + '📆 मिति: ' + shortDayNe(f.paidOn) + NL + '━━━━━━━━━━━━━━' + NL + 'धन्यवाद! 🙏' + foot();
}

/* ---------- derived data ---------- */
function feeState(f) { if (f.paidOn) return { k: 'paid', d: 0 }; var d = daysBetween(today, parse(f.due)); return d > 0 ? { k: 'late', d: d } : { k: 'soon', d: -d }; }
function sortedTests() { return S.tests.slice().sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); }); }
function ranked(t) {
  var out = S.marks.filter(function (m) { return m.testId === t.id; }).map(function (m) { return { s: stu(m.studentId), m: Number(m.m), rank: m.rank }; }).filter(function (x) { return x.s; }).sort(function (a, b) { return b.m - a.m; });
  var r = 0, prev = null;
  out.forEach(function (x, i) { if (x.m !== prev) { r = i + 1; prev = x.m; } if (x.rank == null) x.rank = r; });
  return out;
}
function avgOf(t) { if (t.avg != null) return Number(t.avg); var r = ranked(t); return r.length ? r.reduce(function (x, y) { return x + y.m; }, 0) / r.length : 0; }
function studentTests(sid) {
  var o = []; sortedTests().forEach(function (t) { var m = DB.markOf(t.id, sid); if (m) o.push({ t: t, r: { m: Number(m.m), rank: m.rank } }); }); return o;
}
function deltaFor(t, sid, m) {
  var ts = sortedTests(), i = ts.indexOf(ts.filter(function (x) { return x.id === t.id; })[0]), prev = ts[i + 1];
  if (!prev) return null; var pm = DB.markOf(prev.id, sid); if (!pm) return null;
  return Math.round((m / t.max - Number(pm.m) / prev.max) * 100);
}
function deltaText(d) { return d == null ? '' : (d > 0 ? '📈 अघिल्लो परीक्षाभन्दा ' + ne(d) + '% सुधार' : d < 0 ? '📉 अघिल्लो परीक्षाभन्दा ' + ne(Math.abs(d)) + '% कमी' : '➖ अघिल्लो परीक्षा जत्तिकै'); }
function newReceipt(month) { var n = S.fees.filter(function (f) { return f.rcpt; }).length + 1; return 'R' + month.replace('-', '') + '-' + ('00' + n).slice(-3) + '-' + uid().slice(-3).toUpperCase(); }
function attCounts(sid) { var t = DB.IDX.att[sid] || {}, p = 0, a = 0; Object.keys(t).forEach(function (k) { if (t[k] === 'P') p++; else if (t[k] === 'A') a++; }); return { p: p, a: a }; }
function attPct(sid) { var c = attCounts(sid); return c.p + c.a ? Math.round(c.p / (c.p + c.a) * 100) : null; }
function allAttPct() { var p = 0, a = 0; Object.keys(DB.IDX.att).forEach(function (sid) { if (!stu(sid)) return; var c = attCounts(sid); p += c.p; a += c.a; }); return p + a ? Math.round(p / (p + a) * 100) : null; }

/* ---------- views ---------- */
function titleBar(t, sub) { return '<div class="stack"><h1>' + t + '</h1>' + (sub ? '<p class="muted">' + sub + '</p>' : '') + '</div>'; }
function viewEmpty() {
  return titleBar('Welcome', 'Add your first batch and student, or load sample data to see how every screen works.') +
    '<div class="hero"><span class="lbl">Fees · Attendance · Tests · Parents</span><span class="big" style="font-size:28px">Your centre, in one app</span><span class="sub">Nepali WhatsApp reminders, BS dates, eSewa payment.</span></div>' +
    '<button class="btn primary block" data-act="batchform">' + ic('plus', 18) + 'Add a batch</button><button class="btn block" data-act="stuform">' + ic('plus', 18) + 'Add a student</button><button class="btn block" data-act="seed">Load sample data</button>' +
    '<p class="note">Sample students are marked as sample and can be removed in one tap from the Admin tab. Their phone numbers are not real.</p>';
}
var AVC = ['#6D4AE0', '#E8743B', '#1AA6B7', '#D6457A', '#2F9E63', '#B7791F'];
function avc(n) { var h = 0, t = String(n); for (var i = 0; i < t.length; i++) h = (h * 31 + t.charCodeAt(i)) % 997; return AVC[h % AVC.length]; }
function ini(n) { var w = String(n).trim().split(/\s+/); return ((w[0] || '').charAt(0) + (w.length > 1 ? w[w.length - 1].charAt(0) : '')).toUpperCase(); }
function av(n) { return '<div class="av" style="background:' + avc(n) + '" aria-hidden="true">' + esc(ini(n)) + '</div>'; }
function feeRow(x) {
  var s = x.s, f = x.f, b = batchOf(s);
  var chip = x.d > 0 ? '<span class="chip late">' + x.d + ' days late</span>' : '<span class="chip warn">Due in ' + (-x.d) + ' days</span>';
  return '<div class="row">' + av(s.name) + '<div class="grow"><b>' + esc(s.name) + '</b><small>Class ' + esc(s.cls) + (b ? ' · ' + esc(b.name) : '') + ' · ' + monthLabel(f.month) + '</small></div>' +
    '<div class="right stack" style="align-items:flex-end;gap:6px"><b class="num">' + rs(bal(f)) + '</b>' + (f.part ? '<small>' + rs(f.part) + ' of ' + rs(f.amount) + ' paid</small>' : '') + chip + '</div></div>' +
    '<div class="wrap" style="padding-bottom:10px"><a class="btn wa sm" target="_blank" rel="noopener" href="' + esc(waHref(s.whatsapp, msgFee(s, f))) + '">' + ic('wa', 18) + 'Remind parent</a><button class="btn sm" data-act="partform" data-id="' + esc(f.id) + '">Part payment</button><button class="btn sm" data-act="paid" data-id="' + esc(f.id) + '">Mark paid</button></div>';
}
function viewFees() {
  var m0 = monthKey(today);
  var un = S.fees.filter(function (f) { return !f.paidOn; }).map(function (f) { return { f: f, s: stu(f.studentId), d: daysBetween(today, parse(f.due)) }; }).filter(function (x) { return x.s; }).sort(function (a, b) { return b.d - a.d; });
  var late = un.filter(function (x) { return x.d > 0; }), soon = un.filter(function (x) { return x.d <= 0; });
  var sum = function (a) { return a.reduce(function (t, x) { return t + bal(x.f); }, 0); };
  var missing = S.students.filter(function (s) { return batchOf(s) && !S.fees.some(function (f) { return f.studentId === s.id && f.month === m0; }); });
  var paid = S.fees.filter(function (f) { return f.paidOn && stu(f.studentId); }).sort(function (a, b) { return String(b.paidOn).localeCompare(String(a.paidOn)); }).slice(0, 5);
  var ns = {}, nb = {}; un.forEach(function (x) { ns[x.s.id] = 1; if (x.s.batchId) nb[x.s.batchId] = 1; });
  var h = titleBar('Fees pending', monthLabel(m0) + ' · all batches');
  h += '<div class="hero"><span class="lbl">Pending in total</span><span class="big">' + rs(sum(un)) + '</span><span class="sub">' + Object.keys(ns).length + ' students · ' + Object.keys(nb).length + ' batches</span><span class="pill">' + late.length + ' late</span></div>';
  h += '<button class="btn wa solid block" data-act="remindq"' + (late.length ? '' : ' disabled') + '>' + ic('wa', 20) + 'WhatsApp reminder to all (' + late.length + ')</button>';
  if (missing.length) h += '<button class="btn block" data-act="genfees">' + ic('plus', 18) + 'Create ' + monthLabel(m0) + ' fees for ' + missing.length + ' students</button>';
  var q = (ui.q || '').toLowerCase(), mt = function (x) { return !q || String(x.s.name).toLowerCase().indexOf(q) >= 0; };
  var lateV = late.filter(mt), soonV = soon.filter(mt);
  h += '<div class="card"><input data-search="q" type="search" placeholder="Search student name" value="' + esc(ui.q || '') + '" aria-label="Search student"><div class="filters" role="group" aria-label="Filter">' + [['all', 'All'], ['late', 'Late'], ['soon', 'Coming up']].map(function (o) { return '<button data-act="ffilter" data-v="' + o[0] + '" aria-pressed="' + (ui.ff === o[0]) + '">' + o[1] + '</button>'; }).join('') + '</div></div>';
  if (ui.ff !== 'soon') h += '<div class="card"><h2>Late</h2>' + (lateV.length ? lateV.map(feeRow).join('') : '<p class="muted">' + (q ? 'No match.' : 'Nobody is late. Good.') + '</p>') + '</div>';
  if (ui.ff !== 'late' && soonV.length) h += '<div class="card"><h2>Coming up</h2>' + soonV.map(feeRow).join('') + '</div>';
  if (paid.length) h += '<div class="card"><h2>Recently paid</h2>' + paid.map(function (f) { var s = stu(f.studentId); return '<div class="row">' + av(s.name) + '<div class="grow"><b>' + esc(s.name) + '</b><small>' + monthLabel(f.month) + ' · paid ' + shortDay(f.paidOn) + '</small></div><b class="num">' + rs(f.amount) + '</b><button class="btn sm" data-act="receipt" data-id="' + esc(f.id) + '">Receipt</button><button class="btn sm" data-act="unpaid" data-id="' + esc(f.id) + '">Undo</button></div>'; }).join('') + '</div>';
  return h;
}
function viewAtt() {
  var list = S.students.filter(function (s) { return ui.batch === 'all' || s.batchId === ui.batch; }).sort(byName);
  var np = 0, na = 0; list.forEach(function (s) { var v = DB.attDay(s.id, ui.date); if (v === 'P') np++; else if (v === 'A') na++; });
  var bt = ui.batch === 'all' ? null : get('batches', ui.batch);
  var h = titleBar('Attendance', 'Tap P or A. Absent children get a parent alert.');
  h += '<div class="hero"><span class="lbl">' + (bt ? esc(bt.name) : 'All batches') + (bt && bt.timing ? ' · ' + esc(bt.timing) : '') + '</span><span class="big">' + np + ' / ' + list.length + '</span><span class="sub">' + dayLabel(ui.date) + ' · present today</span><div class="split"><span class="pill">Present ' + np + '</span><span class="pill">Absent ' + na + '</span><span class="pill">Not marked ' + (list.length - np - na) + '</span></div></div>';
  h += '<div class="card"><div class="dates"><button class="btn sm" data-act="dprev" aria-label="Previous day">' + ic('left', 18) + '</button><b>' + dayLabel(ui.date) + '</b><button class="btn sm" data-act="dnext" aria-label="Next day"' + (ui.date >= TODAY ? ' disabled' : '') + '>' + ic('right', 18) + '</button></div>' +
    '<div class="filters" role="group" aria-label="Batch"><button data-act="batch" data-id="all" aria-pressed="' + (ui.batch === 'all') + '">All</button>' + S.batches.map(function (b) { return '<button data-act="batch" data-id="' + esc(b.id) + '" aria-pressed="' + (ui.batch === b.id) + '">' + esc(b.name) + '</button>'; }).join('') + '</div>' +
    '<button class="btn sm" data-act="allp">Mark all present</button></div>';
  h += '<div class="card">' + (list.length ? list.map(function (s) {
    var v = DB.attDay(s.id, ui.date), b = batchOf(s), pc = attPct(s.id);
    return '<div class="row" style="flex-wrap:wrap">' + av(s.name) + '<div class="grow"><b>' + esc(s.name) + '</b><small>' + (pc == null ? 'Class ' + esc(s.cls) : pc + '% attendance') + (b ? ' · ' + esc(b.name) : '') + '</small></div>' +
      '<div class="seg" role="group" aria-label="Attendance for ' + esc(s.name) + '"><button class="' + (v === 'P' ? 'on p' : '') + '" data-act="att" data-id="' + esc(s.id) + '" data-v="P" aria-pressed="' + (v === 'P') + '" aria-label="Present">P</button><button class="' + (v === 'A' ? 'on a' : '') + '" data-act="att" data-id="' + esc(s.id) + '" data-v="A" aria-pressed="' + (v === 'A') + '" aria-label="Absent">A</button></div>' +
      (v === 'A' ? '<div style="flex-basis:100%"><a class="btn wa sm" target="_blank" rel="noopener" href="' + esc(waHref(s.whatsapp, msgAbsent(s, ui.date))) + '">' + ic('wa', 18) + 'Alert parent</a></div>' : '') + '</div>';
  }).join('') : '<p class="muted">No students in this batch.</p>') + '</div>';
  h += '<button class="btn wa solid block" data-act="absentq"' + (na ? '' : ' disabled') + '>' + ic('wa', 20) + 'Absent alert to all parents (' + na + ')</button>';
  return h;
}
function viewTests() {
  var ts = sortedTests(); var t = ts.filter(function (x) { return x.id === ui.testId; })[0] || ts[0];
  var h = titleBar('Weekly test report', 'Marks, rank and progress, sent to each parent on WhatsApp.');
  if (!t) return h + '<div class="card"><button class="btn primary" data-act="testform">' + ic('plus', 18) + 'New weekly test</button><div class="empty"><p class="muted">No tests yet. Add this week\'s marks to see ranks and progress.</p></div></div>';
  var rws = ranked(t);
  var hist = ts.slice().reverse(); var hi = hist.indexOf(hist.filter(function (x) { return x.id === t.id; })[0]); hist = hist.slice(Math.max(0, hi - 5), hi + 1);
  var avg = avgOf(t), top = rws[0];
  h += '<div class="hero"><span class="lbl">' + esc(t.title) + ' · ' + dayLabel(t.date) + '</span><span class="big">' + (Math.round(avg * 10) / 10) + ' <span style="font-size:18px;font-weight:600">/ ' + t.max + ' average</span></span>' +
    '<span class="sub">' + (top ? 'Topper: ' + esc(top.s.name) + ' (' + top.m + '/' + t.max + ') · ' : '') + rws.length + ' students</span>' +
    '<div class="chart" role="img" aria-label="Class average of recent tests">' + hist.map(function (x, i) { var pc = Math.max(6, Math.round(avgOf(x) / x.max * 100)); return '<div class="c' + (x.id === t.id ? ' cur' : '') + '"><i style="height:' + pc + '%"></i><small>T' + (i + 1) + '</small></div>'; }).join('') + '</div></div>';
  h += '<div class="card"><button class="btn primary" data-act="testform">' + ic('plus', 18) + 'New weekly test</button>' +
    '<div class="filters" role="group" aria-label="Tests">' + ts.slice(0, 6).map(function (x) { return '<button data-act="test" data-id="' + esc(x.id) + '" aria-pressed="' + (x.id === t.id) + '">' + esc(x.title) + '</button>'; }).join('') + '</div></div>';
  h += '<button class="btn wa solid block" data-act="reportq" data-id="' + esc(t.id) + '">' + ic('wa', 20) + 'Send report to all parents</button>';
  h += '<div class="card"><h2>Ranks</h2>' + rws.map(function (x) {
    var d = deltaFor(t, x.s.id, x.m), pct = Math.max(0, Math.min(100, Math.round(x.m / t.max * 100)));
    return '<div class="row" style="flex-wrap:wrap"><div class="rank ' + (x.rank === 1 ? 'top1' : '') + '">' + x.rank + '</div>' + av(x.s.name) + '<div class="grow"><b>' + esc(x.s.name) + '</b><div class="prog" role="img" aria-label="' + pct + ' percent"><i style="width:' + pct + '%"></i></div></div><div class="right"><b class="num">' + x.m + '/' + t.max + '</b>' + (d == null ? '' : '<div><span class="chip ' + (d > 0 ? 'good' : d < 0 ? 'late' : '') + '">' + (d > 0 ? 'Up ' + d + '%' : d < 0 ? 'Down ' + Math.abs(d) + '%' : 'Same') + '</span></div>') + '</div>' +
      '<div style="flex-basis:100%;padding-left:48px"><a class="btn wa sm" target="_blank" rel="noopener" href="' + esc(waHref(x.s.whatsapp, msgReport(x.s, t, x, rws.length, deltaText(d)))) + '">' + ic('wa', 18) + 'Share report</a></div></div>';
  }).join('') + '</div>';
  return h;
}
function visibleStudents() { return S.students.slice(); }
function viewDash() {
  var m0 = monthKey(today); var fm = S.fees.filter(function (f) { return f.month === m0 && stu(f.studentId); });
  var col = 0, pen = 0; fm.forEach(function (f) { if (f.paidOn) col += Number(f.amount); else { col += Number(f.part || 0); pen += bal(f); } });
  var tot = col + pen, pc = tot ? Math.round(col / tot * 100) : 0;
  var h = titleBar('Admin dashboard', esc(centre()));
  var ap = allAttPct();
  h += '<div class="hero"><span class="lbl">Fees collected · ' + monthLabel(m0) + '</span><span class="big">' + rs(col) + '</span><div class="hbar" role="img" aria-label="' + pc + ' percent collected"><i style="width:' + pc + '%"></i></div><span class="sub">' + pc + '% collected · ' + rs(pen) + ' pending</span></div>';
  h += '<div class="tiles"><div class="tile"><b>' + S.students.length + '</b><small>students</small></div><div class="tile"><b>' + (ap == null ? '-' : ap + '%') + '</b><small>attendance</small></div><div class="tile"><b>' + S.enquiries.filter(function (e) { return e.status === 'new'; }).length + '</b><small>new enquiries</small></div></div>';
  h += '<div class="card"><div class="dates"><h2>Students</h2><button class="btn sm" data-act="stuform">' + ic('plus', 18) + 'Add</button></div>' + '<input data-search="sq" type="search" placeholder="Search student name" value="' + esc(ui.sq || '') + '" aria-label="Search student">' +
    (S.students.length ? S.students.slice().filter(function (s) { return !ui.sq || String(s.name).toLowerCase().indexOf(ui.sq.toLowerCase()) >= 0; }).sort(byName).map(function (s) { var b = batchOf(s); return '<div class="row">' + av(s.name) + '<div class="grow"><b>' + esc(s.name) + '</b><small>Class ' + esc(s.cls) + (b ? ' · ' + esc(b.name) : '') + ' · ' + esc(s.whatsapp || 'no WhatsApp') + (s.login ? ' · has login' : '') + '</small></div><div class="wrap" style="flex:none;justify-content:flex-end"><button class="btn sm" data-act="profile" data-id="' + esc(s.id) + '">Profile</button><button class="btn sm" data-act="stuform" data-id="' + esc(s.id) + '">Edit</button></div></div>'; }).join('') : '<div class="empty"><p class="muted">No students yet.</p><button class="btn primary" data-act="seed">Load sample data</button></div>') + '</div>';
  h += '<div class="card"><div class="dates"><h2>Batches</h2><button class="btn sm" data-act="batchform">' + ic('plus', 18) + 'Add</button></div>' +
    (S.batches.length ? S.batches.map(function (b) { var n = S.students.filter(function (s) { return s.batchId === b.id; }).length; var tc = b.teacherId ? get('staff', b.teacherId) : null; return '<div class="row" style="flex-wrap:wrap"><div class="grow"><b>' + esc(b.name) + '</b><small>' + shiftLabel(b) + (b.timing ? ' · ' + esc(b.timing) : '') + ' · ' + n + ' students · ' + (tc ? 'Teacher ' + esc(tc.name) : 'No teacher yet') + '</small></div><b class="num">' + rs(b.fee) + '/month</b><button class="btn sm" data-act="batchform" data-id="' + esc(b.id) + '">Edit</button></div>'; }).join('') : '<p class="muted">Add a batch with its monthly fee, then add students to it.</p>') + '</div>';
  h += '<div class="card"><div class="dates"><h2>Refer a friend</h2><button class="btn sm" data-act="enqform">' + ic('plus', 18) + 'Add</button></div>' +
    (S.enquiries.length ? S.enquiries.slice().sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); }).map(function (e) {
      var r = stu(e.referredBy); var cls = e.status === 'joined' ? 'good' : e.status === 'contacted' ? 'warn' : '';
      return '<div class="row">' + av(e.name) + '<div class="grow"><b>' + esc(e.name) + '</b><small>' + (r ? 'Referred by ' + esc(r.name) + ' · ' : '') + shortDay(e.date) + '</small></div><button class="chip ' + cls + '" style="border:0;cursor:pointer;min-height:44px;padding:0 14px" data-act="enqstatus" data-id="' + esc(e.id) + '" aria-label="Change status, now ' + esc(e.status) + '">' + esc(e.status) + '</button></div>';
    }).join('') : '<p class="muted">Enquiries from parents who refer a friend show up here.</p>') + '</div>';
  h += dashExtras() + teachersCard() + archivedCard() + backupCard() + secCard();
  h += '<div class="card"><h2>Automations</h2><p class="muted">Each rule below is the message your parents would get. Run it by hand now; hands-free sending on a schedule needs the WhatsApp Business API and a small server.</p>' +
    autoRow('Fee reminder on the 5th, again to late payers', 'Opens the late-fees list', 'remindq', 'Run now') +
    autoRow('Alert parent the moment a child is marked absent', 'Opens today\'s absent list', 'absentq', 'Run now') +
    autoRow('Weekly report to parents every Sunday', 'Opens the latest test report', 'reportq', 'Run now') +
    '<div class="row"><div class="grow"><b>Receipt on payment, alert to admin</b><small>Receipt is created the moment fees are marked paid</small></div><span class="chip good">Built in</span></div>' +
    '<button class="btn" data-act="setform">Centre settings (name, eSewa)</button></div>';
  return h;
}
function autoRow(t, sub, act, btn) { return '<div class="row"><div class="grow"><b>' + t + '</b><small>' + sub + '</small></div><button class="btn sm" data-act="' + act + '" data-auto="1">' + btn + '</button></div>'; }

/* ---------- render ---------- */
var TABS = [['fees', 'Fees', 'fees'], ['att', 'Attendance', 'att'], ['shifts', 'Shifts', 'clock'], ['tests', 'Tests', 'tests'], ['me', 'My shifts', 'cap'], ['dash', 'Admin', 'dash']];
var ROLE_TABS = { owner: ['fees', 'att', 'shifts', 'tests', 'dash'], teacher: ['att', 'shifts', 'tests', 'me'] };
var ALLOW = {
  teacher: ['veil', 'close', 'logout', 'showpw', 'sentmark', 'copy', 'privacy', 'att', 'allp', 'batch', 'dprev', 'dnext', 'absentq', 'test', 'testform', 'reportq', 'hwform', 'sfilter', 'shiftedit', 'shiftstu']
};
var UNAUTH = ['lrole', 'forgot', 'privacy', 'showpw', 'veil', 'close', 'copy'];
function curTabs() { var r = role() || 'owner'; return TABS.filter(function (t) { return ROLE_TABS[r].indexOf(t[0]) >= 0; }); }
function loadingCard(t) { return '<div class="card center"><p class="muted">' + t + '</p></div>'; }
function renderMain() {
  var app = $('#app'), nav = document.querySelector('nav.tabs');
  var authed = !!ui.session, r = role();
  var gate = !ui.booted || !authed || !DB.state.ready || !!ui.fatal || !DB.configured;
  document.body.classList.toggle('noauth', gate); nav.hidden = gate;
  if (r && ROLE_TABS[r].indexOf(ui.tab) < 0) ui.tab = ROLE_TABS[r][0];
  $('#tabs').innerHTML = curTabs().map(function (t) { return '<button data-tab="' + t[0] + '"' + (ui.tab === t[0] ? ' aria-current="page"' : '') + '>' + ic(t[2], 22) + t[1] + '</button>'; }).join('');
  var head = '<div class="top"><div class="brand"><div class="logo">' + ic('cap', 20) + '</div><div><b>' + esc(centre()) + '</b><small>TUITIONAPP</small></div></div><div class="wrap">' + (authed ? '<button class="btn sm" data-act="logout">Log out</button>' : '') + '</div></div>';
  if (!DB.configured) { app.innerHTML = head + viewConfig(); return; }
  if (ui.fatal) { app.innerHTML = head + '<div class="card"><h2>Could not start</h2><p class="muted">' + esc(ui.fatal) + '</p><button class="btn primary" data-act="reload">Try again</button></div>'; return; }
  if (!ui.booted) { app.innerHTML = head + loadingCard('Loading...'); return; }
  if (!authed) { app.innerHTML = head + (ui.info ? viewLogin() : viewSetup()); return; }
  if (!DB.state.ready) { app.innerHTML = head + loadingCard('Loading your centre...'); return; }
  var body;
  if (r === 'owner' && ui.tab !== 'dash' && ui.tab !== 'shifts' && !S.students.length) body = viewEmpty();
  else if (r === 'teacher' && ui.tab !== 'me' && ui.tab !== 'shifts' && !S.students.length) body = titleBar('Welcome', 'No students yet. Ask the admin to add students.');
  else body = ({ fees: viewFees, att: viewAtt, tests: viewTests, dash: viewDash, me: viewMe, shifts: viewShifts })[ui.tab]();
  app.innerHTML = head + body;
  if (r === 'owner' && !ui.bakNudged) { ui.bakNudged = true; var lb = settings().lastBackup, dd = lb ? daysBetween(today, parse(lb)) : null; if (lb == null) toast('No backup yet. Download one in the Admin tab.'); else if (dd >= 7) toast('No backup for ' + dd + ' days. Download one in the Admin tab.'); }
}
function render() { renderMain(); limits(); }
function limits() { document.querySelectorAll('input:not([type=checkbox]):not([type=file]):not([maxlength])').forEach(function (i) { i.maxLength = i.type === 'password' ? 100 : 200; }); }

/* ---------- activity log ---------- */
var AUD = { students: 1, fees: 1, tests: 1, staff: 1, settings: 1, batches: 1, claims: 1, notices: 1, homework: 1, salary: 1 };
function describe(c, r) {
  if (c === 'students') return 'Student ' + (r.name || '');
  if (c === 'fees') { var s = stuAny(r.studentId); return 'Fee ' + (s ? s.name : '') + ' ' + (r.month ? monthLabel(r.month) : ''); }
  if (c === 'tests') return 'Test ' + (r.title || '');
  if (c === 'staff') return 'Teacher ' + (r.name || '');
  if (c === 'settings') return 'Settings';
  if (c === 'batches') return 'Batch ' + (r.name || '');
  if (c === 'claims') return 'Payment claim (' + (r.status || '') + ')';
  if (c === 'notices') return 'Notice';
  if (c === 'salary') { var tt0 = get('staff', r.staffId); return 'Salary ' + (tt0 ? tt0.name : '') + ' ' + (r.month ? monthLabel(r.month) : ''); }
  return 'Homework';
}
function who() {
  var s = ui.session; if (!s) return 'Not logged in';
  if (s.role === 'owner') return 'Admin';
  if (s.role === 'teacher') return 'Teacher ' + (s.name || '');
  return 'Parent ' + (s.name || '');
}
function logEv(text) { return; put('logs', 'l' + uid(), { t: Date.now(), who: who(), text: String(text).slice(0, 200) }); }
DB.hooks.audit = function (c, id, verb, data) { if (!AUD[c] || ui.noAudit) return; logEv(describe(c, data || get(c, id) || {}) + ' ' + verb); };

/* ---------- session, sign-in, inactivity ---------- */
function limitMs(r) { return (r === 'parent' ? 20 : 10) * 60000; }
function saveAct() { try { sessionStorage.setItem('tuitionapp_act', String(Date.now())); } catch (e) { } }
function lastAct() { try { return Number(sessionStorage.getItem('tuitionapp_act') || 0); } catch (e) { return 0; } }
function authMsg(e) {
  var c = e && e.code || '';
  if (c === 'auth/email-already-in-use') return 'This email already has an account.';
  if (c === 'auth/invalid-email') return 'That email address does not look right.';
  if (c === 'auth/weak-password') return 'Choose a stronger password (6 or more characters).';
  if (c === 'auth/network-request-failed') return 'No internet connection. Try again.';
  if (c === 'auth/too-many-requests') return 'Too many attempts. Wait a few minutes and try again.';
  if (c === 'auth/requires-recent-login') return 'Log in again, then retry.';
  if (c === 'permission-denied') return 'Only the admin can do this. If you are the admin, re-run supabase/schema.sql.';
  if (c === 'auth/invalid-credential' || c === 'auth/wrong-password' || c === 'auth/user-not-found') return 'Wrong password.';
  return 'Something went wrong. Try again.';
}
function onUser(user) {
  if (ui.busy) return;
  if (!user) { DB.stopSession(); ui.session = null; ui.booted = true; render(); return; }
  DB.getUserDoc(user.uid).then(function (us) {
    if (!us.exists() || (us.data().role !== 'owner' && us.data().role !== 'teacher')) { DB.logoutNow(); toast('This login has no access. Ask the centre.'); return; }
    var u = us.data();
    var la = lastAct();
    if (la && Date.now() - la > limitMs(u.role)) { DB.logoutNow(); toast('You were logged out after being inactive.'); return; }
    ui.session = { role: u.role, uid: user.uid, name: u.name || '', ids: u.studentIds || [], staffId: u.staffId || '' };
    ui.denied = false;
    saveAct(); ui.lastAct = Date.now(); ui.booted = true;
    DB.startSession(u.role, ui.session.ids, ui.session.staffId);
    render(); window.scrollTo(0, 0);
  }).catch(function (e) { ui.booted = true; ui.fatal = 'Could not load your account. Check your internet and that supabase/schema.sql has been run.'; render(); });
}
function logout(auto) {
  closeModal(); try { sessionStorage.removeItem('tuitionapp_act'); } catch (e) { } DB.logoutNow().catch(function () { });
  ui.tab = 'fees'; window.scrollTo(0, 0);
  if (auto === true) toast('You were logged out after being inactive.');
}
['click', 'keydown', 'touchstart', 'input'].forEach(function (ev) { document.addEventListener(ev, function () { if (!ui.session) return; var n = Date.now(); if (n - (ui.lastAct || 0) > 2000) { ui.lastAct = n; saveAct(); } }, true); });
setInterval(function () { if (ui.session && Date.now() - (ui.lastAct || 0) > limitMs(ui.session.role)) logout(true); }, 15000);
setInterval(function () { if (iso(new Date()) !== TODAY) location.reload(); }, 60000);

function lockGet() { try { return JSON.parse(localStorage.getItem('tuitionapp_lock') || '{}') || {}; } catch (e) { return {}; } }
function lockSet(o) { try { localStorage.setItem('tuitionapp_lock', JSON.stringify(o)); } catch (e) { } }
function locked() { var l = lockGet(); if (l.until && Date.now() < l.until) { toast('Too many attempts. Try again in ' + Math.ceil((l.until - Date.now()) / 1000) + ' seconds.'); return true; } return false; }
function badLogin() {
  var l = lockGet(); l.fails = (l.fails || 0) + 1;
  if (l.fails >= 5) { l.level = (l.level || 0) + 1; l.fails = 0; var secs = Math.min(900, 30 * Math.pow(2, l.level - 1)); l.until = Date.now() + secs * 1000; lockSet(l); toast('Too many attempts. Locked for ' + secs + ' seconds.'); return; }
  lockSet(l); toast('Wrong username or password.');
}
function goodLogin() { lockSet({}); }
function loginErr(e) {
  var c = e && e.code || '';
  if (c === 'auth/invalid-credential' || c === 'auth/wrong-password' || c === 'auth/user-not-found' || c === 'auth/invalid-email') return badLogin();
  toast(authMsg(e));
}

/* ---------- password helpers ---------- */
var COMMON = ['password', 'password1', '12345678', '123456789', '1234567890', 'qwertyui', 'qwerty123', '11111111', 'abcd1234', 'iloveyou', 'admin123', 'owner123', 'tuition123', 'nepal123', '12341234', 'letmein1', 'welcome1'];
function pwProblem(p, min, strict) {
  if (p.length < min) return 'Use at least ' + min + ' characters.';
  if (/^(.)\1+$/.test(p) || COMMON.indexOf(p.toLowerCase()) >= 0) return 'That password is too easy to guess. Choose another.';
  if (strict && !(/[A-Za-z]/.test(p) && /\d/.test(p))) return 'Use both letters and numbers.';
  return '';
}
function pwScore(p) { var s = 0; if (p.length >= 8) s++; if (p.length >= 12) s++; if (/[a-z]/.test(p) && /[A-Z]/.test(p)) s++; if (/\d/.test(p)) s++; if (/[^A-Za-z0-9]/.test(p)) s++; return s; }
function meter(inp) {
  var m = inp.parentElement.querySelector('[data-meter]'); if (!m) return; var p = inp.value;
  if (!p) { m.innerHTML = ''; return; }
  var sc = pwScore(p); m.innerHTML = '<span class="chip ' + (sc <= 2 ? 'late' : sc === 3 ? 'warn' : 'good') + '">' + (sc <= 2 ? 'Weak' : sc === 3 ? 'Okay' : 'Strong') + '</span>';
}

/* ---------- screens before login ---------- */
var SHOWPW = '<label style="flex-direction:row;align-items:center;gap:8px;font-weight:500"><input type="checkbox" data-act="showpw" style="width:20px;min-height:20px;flex:none"> Show password</label>';
function viewConfig() {
  return '<div class="card"><h2>Connect Supabase first</h2><p class="muted">Open <b>js/supabase-config.js</b> and paste your Supabase project URL and anon key, then deploy again. The README has the steps.</p></div>';
}
function viewSetup() {
  return '<div class="stack"><h1>Set up your centre</h1><p class="muted">You are the first person here, so you become the admin. This can be done only once.</p></div>' +
    '<div class="card"><form data-form="setup" class="stack"><label>Centre name<input name="centre" required maxlength="80" autocomplete="organization"></label><label>Your email (to log in and to reset your password)<input name="email" type="email" required autocomplete="username" autocapitalize="none" spellcheck="false"></label><label>Password<input name="pw" type="password" data-pw data-strength required minlength="8" autocomplete="new-password"><span data-meter></span></label>' + SHOWPW + '<button class="btn primary block" type="submit">Create admin account</button></form><p class="note">Password: at least 8 characters with letters and numbers. Use an email you can open, because password reset links go there.</p></div>';
}
function viewLogin() {
  var r = ui.lrole || 'owner';
  return '<div class="hero"><span class="lbl">' + esc(centre()) + '</span><span class="big" style="font-size:30px">Welcome back</span><span class="sub">Log in to continue.</span></div>' +
    '<div class="card"><div class="filters" role="group" aria-label="Log in as">' + ['owner', 'teacher'].map(function (x) { return '<button data-act="lrole" data-v="' + x + '" aria-pressed="' + (r === x) + '">' + (x === 'owner' ? 'Admin' : x.charAt(0).toUpperCase() + x.slice(1)) + '</button>'; }).join('') + '</div>' +
    '<form data-form="login" class="stack">' + (r === 'owner' ? '<label>Email<input name="email" type="email" required autocomplete="username" autocapitalize="none" spellcheck="false"></label>' : '<label>Username (' + 'your mobile number' + ')<input name="phone" inputmode="tel" required autocomplete="username" placeholder="98XXXXXXXX"></label>') +
    '<label>Password<input name="pw" type="password" data-pw required autocomplete="current-password"></label>' + SHOWPW + '<button class="btn primary block" type="submit">Log in</button></form>' +
    (r === 'owner' ? '<button class="linkbtn" data-act="forgot">Forgot password?</button>' : '<p class="note">Your password is set by the admin. Ask the admin if you forgot it.</p>') +
    '<p class="note">By logging in you agree to the <button class="linkbtn" data-act="privacy">privacy notice</button>.</p></div>';
}
function forgotModal() {
  openModal(head('Reset admin password') + '<form data-form="forgot" class="stack"><label>Admin email<input name="email" type="email" required autocomplete="username"></label><button class="btn primary" type="submit">Send reset link</button></form><p class="note">We email you a link. Open it to choose a new password. Teacher and parent passwords are reset by the admin.</p>', 'Reset password');
}
function chpwModal() {
  openModal(head('Change password') + '<form data-form="chpw" class="stack"><label>Current password<input name="old" type="password" data-pw required autocomplete="current-password"></label><label>New password<input name="pw" type="password" data-pw data-strength required minlength="8" autocomplete="new-password"><span data-meter></span></label><label>Confirm new password<input name="pw2" type="password" data-pw required minlength="8" autocomplete="new-password"></label>' + SHOWPW + '<button class="btn primary" type="submit">Save password</button></form>', 'Change password');
}
function privacyModal() {
  openModal(head('Privacy notice') + '<div class="stack">' +
    '<div><h2>What we store</h2><p class="muted">Student name and class, parent name and WhatsApp number, attendance, test marks, fees and payments.</p></div>' +
    '<div><h2>Why</h2><p class="muted">To run classes, share progress with parents and collect fees. Nothing is sold or shared with anyone else.</p></div>' +
    '<div><h2>Who can see it</h2><p class="muted">The admin sees everything. Teachers see attendance, marks and homework but not fees. Parents do not log in; they only get WhatsApp messages from the centre.</p></div>' +
    '<div><h2>WhatsApp</h2><p class="muted">Messages go only to parents who have not opted out. Tell the centre if you do not want messages.</p></div>' +
    '<div><h2>Keeping and deleting</h2><p class="muted">When a student leaves, the record is archived. You can ask the centre to correct or delete your data at any time. Passwords are handled by Supabase and are never stored as plain text.</p></div>' +
    '<div><h2>नेपालीमा</h2><p class="muted">हामी विद्यार्थीको नाम र कक्षा, अभिभावकको नाम र WhatsApp नम्बर, उपस्थिति, परीक्षाको अङ्क र शुल्कको विवरण राख्छौं। यो कक्षा सञ्चालन, प्रगति जानकारी र शुल्क सङ्कलनका लागि मात्र प्रयोग हुन्छ। मालिकले सबै हेर्न सक्छन्, शिक्षकले शुल्क बाहेक अरू हेर्न सक्छन्, र अभिभावकले आफ्नो बच्चाको विवरण मात्र हेर्न सक्छन्। WhatsApp सन्देश नचाहिएमा केन्द्रलाई जानकारी दिनुहोस्। विद्यार्थीले पढाइ छाडेपछि विवरण अभिलेखमा राखिन्छ। विवरण सच्याउन वा हटाउन केन्द्रलाई भन्न सक्नुहुन्छ।</p></div>' +
    '</div>', 'Privacy');
}

/* ---------- teachers ---------- */
/* ---------- shifts and teacher pay ---------- */
var SHIFT = { morning: 'Morning shift', day: 'Day shift', evening: 'Evening shift', any: 'Any time (flexible)' };
var AVAIL = { any: 'Any time', morning: 'Morning', day: 'Day', evening: 'Evening' };
function shiftLabel(b) { return SHIFT[b.shift] || 'Shift'; }
function shiftOpts(sel) { return Object.keys(SHIFT).map(function (k) { return '<option value="' + k + '"' + (k === (sel || 'morning') ? ' selected' : '') + '>' + SHIFT[k] + '</option>'; }).join(''); }
function shiftsOf(tid) { return S.batches.filter(function (b) { return b.teacherId === tid; }); }
function payDue(t) { var n = shiftsOf(t.id).length; return t.payType === 'shift' ? Number(t.pay || 0) * n : Number(t.pay || 0); }
function payBasis(t) { var n = shiftsOf(t.id).length; return t.payType === 'shift' ? rs(t.pay || 0) + ' per shift × ' + n + (n === 1 ? ' shift' : ' shifts') : 'Fixed monthly salary'; }
function teacherFees(t, m) {
  var ids = {}; shiftsOf(t.id).forEach(function (b) { ids[b.id] = 1; });
  var col = 0, pen = 0;
  S.fees.forEach(function (f) { var s = stu(f.studentId); if (!s || !ids[s.batchId] || f.month !== m) return; if (f.paidOn) col += Number(f.amount); else { col += Number(f.part || 0); pen += bal(f); } });
  return { col: col, pen: pen };
}
function shiftOrder(b) { var i = Object.keys(SHIFT).indexOf(b.shift); return i < 0 ? 9 : i; }
function viewShifts() {
  var bs = S.batches.slice().sort(function (a, b) { return shiftOrder(a) - shiftOrder(b) || String(a.name).localeCompare(String(b.name)); });
  var f = ui.sf || 'all', vis = bs.filter(function (b) { return f === 'all' || b.shift === f; });
  var cnt = function (k) { return bs.filter(function (b) { return b.shift === k; }).length; };
  var isAdmin = role() === 'owner';
  var h = titleBar('Tuition batch shifts', 'Each batch runs in one shift. See how many shifts you have and who teaches them.');
  h += '<div class="hero"><span class="lbl">Shifts (batches)</span><span class="big">' + bs.length + '</span><span class="sub">' + Object.keys(SHIFT).map(function (k) { return SHIFT[k].replace(' shift', '').replace(' (flexible)', '') + ' ' + cnt(k); }).join(' · ') + '</span><span class="pill">' + S.students.length + ' students</span></div>';
  h += '<div class="card">' + (isAdmin ? '<button class="btn primary" data-act="batchform">' + ic('plus', 18) + 'Add batch and shift</button>' : '') + '<div class="filters" role="group" aria-label="Shift">' + [['all', 'All (' + bs.length + ')']].concat(Object.keys(SHIFT).map(function (k) { return [k, SHIFT[k].replace(' shift', '').replace(' (flexible)', '') + ' (' + cnt(k) + ')']; })).map(function (o) { return '<button data-act="sfilter" data-v="' + o[0] + '" aria-pressed="' + (f === o[0]) + '">' + o[1] + '</button>'; }).join('') + '</div></div>';
  h += '<div class="card">' + (vis.length ? vis.map(function (b) {
    var n = S.students.filter(function (s) { return s.batchId === b.id; }).length, tc = b.teacherId ? get('staff', b.teacherId) : null;
    return '<div class="row" style="flex-wrap:wrap"><div class="grow"><b>' + esc(b.name) + '</b><small>' + shiftLabel(b) + (b.timing ? ' · ' + esc(b.timing) : '') + ' · ' + n + ' students · ' + (tc ? 'Teacher ' + esc(tc.name) : 'No teacher yet') + '</small></div>' +
      '<div class="wrap" style="flex:none"><button class="btn sm" data-act="shiftstu" data-id="' + esc(b.id) + '">Students</button><button class="btn sm" data-act="' + (isAdmin ? 'batchform' : 'shiftedit') + '" data-id="' + esc(b.id) + '">Edit</button></div></div>';
  }).join('') : '<p class="muted">' + (bs.length ? 'No batch in this shift.' : 'No batches yet. ' + (isAdmin ? 'Add a batch and choose its shift.' : 'Ask the admin to add batches.')) + '</p>') + '</div>';
  return h;
}
function shiftForm(id) {
  var b = get('batches', id); if (!b) return;
  openModal(head('Edit shift') + '<p class="muted">' + esc(b.name) + '</p><form data-form="shift" data-id="' + esc(id) + '" class="stack"><label>Shift<select name="shift">' + shiftOpts(b.shift) + '</select></label><label>Timing<input name="timing" value="' + esc(b.timing || '') + '" placeholder="5 to 7 pm, or leave empty for any time"></label><label>Teacher<select name="teacherId"><option value="">Not assigned</option>' + S.staff.slice().sort(byName).map(function (t) { return '<option value="' + esc(t.id) + '"' + (t.id === b.teacherId ? ' selected' : '') + '>' + esc(t.name) + '</option>'; }).join('') + '</select></label><button class="btn primary" type="submit">Save shift</button></form>', 'Shift');
}
function shiftStudents(id) {
  var b = get('batches', id); if (!b) return;
  var l = S.students.filter(function (s) { return s.batchId === id; }).sort(byName);
  openModal(head(esc(b.name)) + '<p class="muted">' + shiftLabel(b) + (b.timing ? ' · ' + esc(b.timing) : '') + ' · ' + l.length + ' students</p>' + (l.length ? l.map(function (s) { return '<div class="row">' + av(s.name) + '<div class="grow"><b>' + esc(s.name) + '</b><small>Class ' + esc(s.cls) + '</small></div></div>'; }).join('') : '<p class="muted">No students in this batch.</p>'), 'Students');
}
function viewMe() {
  var t = get('staff', ui.session.staffId), h = titleBar('My shifts', t ? esc(t.name) : '');
  if (!t) return h + '<div class="card"><p class="muted">Your teacher record was not found. Ask the admin to save your teacher details again.</p></div>';
  var bs = shiftsOf(t.id), m0 = monthKey(today), sal = get('salary', t.id + '_' + m0);
  h += '<div class="hero"><span class="lbl">Shifts you teach</span><span class="big">' + bs.length + '</span><span class="sub">Available: ' + (AVAIL[t.avail] || AVAIL.any) + '</span></div>';
  h += '<div class="card"><h2>Your shifts</h2>' + (bs.length ? bs.map(function (b) { var n = S.students.filter(function (s) { return s.batchId === b.id; }).length; return '<div class="row"><div class="grow"><b>' + esc(b.name) + '</b><small>' + shiftLabel(b) + (b.timing ? ' · ' + esc(b.timing) : '') + ' · ' + n + ' students</small></div></div>'; }).join('') : '<p class="muted">No shifts assigned yet. Ask the admin.</p>') + '</div>';
  var hist = S.salary.slice().sort(function (a, b) { return String(b.month).localeCompare(String(a.month)); }).slice(0, 6);
  h += '<div class="card"><h2>Your pay</h2><div class="row"><div class="grow"><b>' + monthLabel(m0) + '</b><small>' + payBasis(t) + '</small></div><b class="num">' + rs(payDue(t)) + '</b><span class="chip ' + (sal ? 'good' : 'warn') + '">' + (sal ? 'Paid ' + shortDay(sal.paidOn) : 'Not paid yet') + '</span></div>' +
    (hist.length ? '<h3>Paid before</h3>' + hist.map(function (x) { return '<div class="row"><div class="grow"><b>' + monthLabel(x.month) + '</b><small>Paid ' + shortDay(x.paidOn) + ' · ' + (x.shifts || 0) + ' shifts</small></div><b class="num">' + rs(x.amount) + '</b></div>'; }).join('') : '') + '</div>';
  return h;
}
function teacherForm(id) {
  var t = id ? get('staff', id) : {}; t = t || {};
  openModal(head(id ? 'Edit teacher' : 'Add a teacher') + '<form data-form="teacher" data-id="' + esc(id || '') + '" class="stack"><label>Name<input name="name" required value="' + esc(t.name || '') + '" autocomplete="off"></label><label>Mobile number (used to log in)<input name="phone" inputmode="tel" required value="' + esc(t.phone || '') + '" placeholder="98XXXXXXXX" autocomplete="off"></label><label>Available for<select name="avail">' + Object.keys(AVAIL).map(function (k) { return '<option value="' + k + '"' + (k === (t.avail || 'any') ? ' selected' : '') + '>' + AVAIL[k] + '</option>'; }).join('') + '</select></label><label>Pay type<select name="payType"><option value="monthly"' + (t.payType !== 'shift' ? ' selected' : '') + '>Fixed monthly salary</option><option value="shift"' + (t.payType === 'shift' ? ' selected' : '') + '>Per shift, each month</option></select></label><label>Pay amount (Rs)<input name="pay" type="number" min="0" step="any" inputmode="decimal" value="' + esc(t.pay == null ? '' : t.pay) + '"></label><p class="note">Assign shifts to this teacher by choosing the teacher in each batch.</p><label>Password<input name="pw" type="text" data-pw autocomplete="off" ' + (t.login ? '' : 'required ') + 'placeholder="' + (t.login ? 'Login exists. Type a new password to reset it' : 'At least 6 characters') + '"></label><button class="btn primary" type="submit">Save</button>' + (id ? '<button class="btn danger" type="button" data-act="delteacher" data-id="' + esc(id) + '">Remove teacher</button>' : '') + '</form>', 'Teacher');
}
function teachersCard() {
  var m0 = monthKey(today), tot = 0, paid = 0;
  var list = S.staff.slice().sort(byName).map(function (t) {
    var bs = shiftsOf(t.id), due = payDue(t), sal = get('salary', t.id + '_' + m0), fs = teacherFees(t, m0);
    tot += due; if (sal) paid += Number(sal.amount || 0);
    return '<div class="row" style="flex-wrap:wrap">' + av(t.name) + '<div class="grow"><b>' + esc(t.name) + '</b><small>' + esc(t.phone) + ' · ' + (AVAIL[t.avail] || AVAIL.any) + ' · ' + bs.length + (bs.length === 1 ? ' shift' : ' shifts') + (bs.length ? ': ' + bs.map(function (b) { return esc(b.name); }).join(', ') : '') + '</small></div>' +
      '<div class="right stack" style="align-items:flex-end;gap:6px"><b class="num">' + rs(due) + '</b><small>' + payBasis(t) + '</small></div>' +
      '<div style="flex-basis:100%"><small>Fees from their batches this month: ' + rs(fs.col) + ' collected, ' + rs(fs.pen) + ' pending</small></div>' +
      '<div style="flex-basis:100%" class="wrap">' + (sal ? '<span class="chip good">Paid ' + shortDay(sal.paidOn) + '</span><button class="btn sm" data-act="unpaysalary" data-id="' + esc(t.id) + '">Undo</button>' : '<button class="btn primary sm" data-act="paysalary" data-id="' + esc(t.id) + '"' + (due > 0 ? '' : ' disabled') + '>Mark ' + monthLabel(m0) + ' pay paid</button>') + '<button class="btn sm" data-act="teacherform" data-id="' + esc(t.id) + '">Edit</button></div></div>';
  }).join('');
  return '<div class="card"><div class="dates"><h2>Teachers and shifts</h2><button class="btn sm" data-act="teacherform">' + ic('plus', 18) + 'Add</button></div><p class="muted">Teachers log in with their mobile number. They take attendance, enter marks, post homework and see their own shifts and pay. They cannot see student fees or the admin screens. Give each batch a shift and a teacher in the Batches list.</p>' +
    (S.staff.length ? '<div class="tiles"><div class="tile"><b>' + S.staff.length + '</b><small>teachers</small></div><div class="tile"><b style="font-size:17px">' + rs(tot) + '</b><small>pay due ' + monthLabel(m0) + '</small></div><div class="tile"><b style="font-size:17px">' + rs(paid) + '</b><small>paid</small></div></div>' + list : '<p class="muted">No teachers yet.</p>') + '</div>';
}
function archivedCard() {
  var a = ALLSTU.filter(function (x) { return x.archived; }); if (!a.length) return '';
  return '<div class="card"><h2>Archived students</h2><p class="muted">Students who left. They are hidden everywhere. Restore them or delete them for good.</p>' + a.sort(byName).map(function (s) { return '<div class="row">' + av(s.name) + '<div class="grow"><b>' + esc(s.name) + '</b><small>Class ' + esc(s.cls) + '</small></div><div class="wrap" style="flex:none"><button class="btn sm" data-act="unarc" data-id="' + esc(s.id) + '">Restore</button><button class="btn danger sm" data-act="delstu" data-id="' + esc(s.id) + '">Delete</button></div></div>'; }).join('') + '</div>';
}

/* ---------- payment claims ---------- */
function pendingClaims() { return S.claims.filter(function (c) { return c.status === 'pending'; }); }
function claimFor(fid) { return S.claims.filter(function (c) { return c.feeId === fid && c.status === 'pending'; })[0]; }
function claimChip(f) { return claimFor(f.id) ? '<span class="chip warn" style="align-self:flex-start">Payment sent. Waiting for the centre to confirm.</span>' : ''; }
function applyPayment(fid, add) {
  var f = get('fees', fid); if (!f) return null; var np = Number(f.part || 0) + add;
  if (np >= Number(f.amount)) { patch('fees', fid, { part: Number(f.amount), paidOn: TODAY, rcpt: f.rcpt || newReceipt(f.month) }); return 'paid'; }
  patch('fees', fid, { part: np }); return 'part';
}
/* ---------- security check, activity log, backup ---------- */
function secCard() {
  var st = settings(), lb = st.lastBackup, days = lb ? daysBetween(today, parse(lb)) : null;
  var rws = [
    ['Admin email', ['good', DB.currentEmail() || '-']],
    ['Last backup', lb ? (days < 7 ? ['good', days === 0 ? 'Today' : days + ' days ago'] : ['warn', days + ' days ago']) : ['late', 'Never']],
    ['Teacher accounts', ['good', String(S.staff.length)]],
    ['Opted out of WhatsApp', ['good', String(S.students.filter(function (s) { return s.optout; }).length)]]
  ];
  return '<div class="card"><h2>Security check</h2>' + rws.map(function (r) { return '<div class="row"><div class="grow"><b>' + r[0] + '</b></div><span class="chip ' + r[1][0] + '">' + esc(r[1][1]) + '</span></div>'; }).join('') +
    '<p class="muted">Only the admin and teachers can log in. Parents get WhatsApp messages and do not need an account.</p>' +
    '<div class="wrap"><button class="btn" data-act="chpw">Change password</button><button class="btn" data-act="privacy">Privacy notice</button><button class="btn" data-act="logout">Log out</button></div></div>';
}
var BK = ['students', 'batches', 'fees', 'att', 'tests', 'marks', 'enquiries', 'homework', 'notices', 'salary'];
function backupCard() {
  var lb = settings().lastBackup;
  return '<div class="card"><h2>Backup and restore</h2><p class="muted">' + (lb ? 'Last backup: ' + shortDay(lb) + '. ' : 'You have not made a backup yet. ') + 'Make one every week and keep the file private, because it holds parent phone numbers. Parent and teacher passwords are not in the file.</p><div class="wrap"><button class="btn primary" data-act="bakdl">Download backup</button><label class="btn" style="cursor:pointer">Restore from file<input type="file" accept=".json,application/json" data-file="restore" style="display:none"></label></div></div>';
}
function doBackup() {
  toast('Preparing backup...');
  DB.fetchAll(BK).then(function (d) {
    var st = settings(); d.settings = [{ id: 'main', centre: st.centre || '', esewa: st.esewa || '' }];
    var buf = new TextEncoder().encode(JSON.stringify({ app: 'TUITIONAPP', version: 2, created: new Date().toISOString(), data: d }));
    return saveBlob('tuitionapp-backup-' + TODAY + '.json', buf, 'application/json').then(function () { patch('settings', 'main', { lastBackup: TODAY }); logEv('Backup downloaded'); render(); toast('Backup saved. Keep the file private.'); });
  }).catch(function () { toast('Could not make the backup.'); });
}
function readRestore(file) {
  if (!file) return;
  if (file.size > 20e6) { toast('That file is too large.'); return; }
  var fr = new FileReader();
  fr.onload = function () {
    var o = null; try { o = JSON.parse(String(fr.result)); } catch (e) { }
    var ok = !!(o && o.app === 'TUITIONAPP' && o.data && typeof o.data === 'object');
    if (ok) BK.forEach(function (c) { var a = o.data[c]; if (a != null && !(Array.isArray(a) && a.every(function (r) { return r && typeof r === 'object' && /^[A-Za-z0-9_-]{1,120}$/.test(String(r.id)); }))) ok = false; });
    if (!ok) { toast('This is not a valid TUITIONAPP backup file.'); return; }
    ui.pendingRestore = o;
    var cnt = BK.map(function (c) { return c + ' ' + ((o.data[c] || []).length); }).join(', ');
    openModal(head('Restore backup') + '<p class="muted">This adds everything in the backup (' + esc(cnt) + ') and overwrites records that have the same id. Nothing else is deleted.</p><form data-form="restore" class="stack"><label>Admin password<input name="pw" type="password" data-pw required autocomplete="current-password"></label><label>Type RESTORE to confirm<input name="word" required autocomplete="off"></label><button class="btn danger" type="submit">Restore now</button></form>', 'Restore');
  };
  fr.onerror = function () { toast('Could not read that file.'); };
  fr.readAsText(file);
}
function applyRestore(o) {
  var jobs = [];
  BK.forEach(function (c) { (o.data[c] || []).forEach(function (r) { jobs.push(['set', c, r.id, strip(r)]); }); });
  var s0 = (o.data.settings || []).filter(function (r) { return r && r.id === 'main'; })[0];
  if (s0) { var cur = strip(settings()); ['centre', 'esewa'].forEach(function (k) { if (s0[k]) cur[k] = s0[k]; }); jobs.push(['set', 'settings', 'main', cur]); }
  toast('Restoring...');
  DB.bulkWrite(jobs).then(function () { jobs.forEach(function (j) { DB.local(j[1], j[2], j[3]); }); logEv('Backup restored'); render(); toast('Backup restored.'); }).catch(fail);
}

/* ---------- login and account forms ---------- */
function authSubmit(k, v) {
  if (k === 'setup') {
    var email = v('email').toLowerCase(), a = v('pw'), cn = v('centre'), pr = pwProblem(a, 8, true);
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) { toast('Enter a valid email address.'); return true; }
    if (!cn) { toast('Enter the centre name.'); return true; }
    if (pr) { toast(pr); return true; }
    ui.busy = true; toast('Creating your account...');
    saveAct();
    DB.createOwner(email, a, cn).then(function (user) {
      ui.busy = false; ui.info = { centre: cn }; saveAct(); onUser(user);
    }).catch(function (e) { ui.busy = false; toast(authMsg(e)); });
    return true;
  }
  if (k === 'login') {
    if (locked()) return true;
    var r = ui.lrole || 'owner';
    if (r === 'owner') { saveAct(); DB.signIn(v('email'), v('pw')).then(function () { goodLogin(); }).catch(loginErr); return true; }
    var num = last10(v('phone'));
    if (num.length < 10) { badLogin(); return true; }
    saveAct();
    DB.getLoginEmail(r, num).then(function (em) { if (!em) { badLogin(); return; } return DB.signIn(em, v('pw')).then(function () { goodLogin(); }); }).catch(loginErr);
    return true;
  }
  if (k === 'forgot') {
    DB.resetPassword(v('email')).then(function () { closeModal(); toast('If this email has an account, a reset link is on its way.'); }).catch(function (e) { if (e && e.code === 'auth/invalid-email') toast(authMsg(e)); else { closeModal(); toast('If this email has an account, a reset link is on its way.'); } });
    return true;
  }
  if (k === 'chpw') {
    var m1 = v('pw'), m2 = v('pw2'), p1 = pwProblem(m1, role() === 'owner' ? 8 : 6, role() === 'owner');
    if (p1) { toast(p1); return true; }
    if (m1 !== m2) { toast('New passwords do not match.'); return true; }
    DB.changePassword(v('old'), m1).then(function () { logEv('Password changed'); closeModal(); toast('Password changed.'); }).catch(function (e) { toast(e && (e.code === 'auth/invalid-credential' || e.code === 'auth/wrong-password') ? 'Current password is wrong.' : authMsg(e)); });
    return true;
  }
  if (k === 'teacher') {
    var id = ui.formId, old = id ? get('staff', id) : null, tid = id || 't' + uid();
    if (!v('name')) { toast('Enter a name.'); return true; }
    if (!validPhone(v('phone'))) { toast('Enter a 10-digit mobile number.'); return true; }
    var phone = last10(v('phone')), pw = v('pw');
    if (S.staff.some(function (x) { return x.id !== tid && last10(x.phone) === phone; })) { toast('A teacher with this number already exists.'); return true; }
    var changed = old && last10(old.phone) !== phone;
    var td = { name: v('name'), phone: phone, created: old ? old.created : TODAY, login: old ? !!old.login && !changed : false, avail: AVAIL[v('avail')] ? v('avail') : 'any', payType: v('payType') === 'shift' ? 'shift' : 'monthly', pay: Math.max(0, Number(v('pay')) || 0) };
    if (!pw && !td.login) { toast('Set a password for the teacher.'); return true; }
    if (pw) {
      var pp = pwProblem(pw, 6, false); if (pp) { toast(pp); return true; }
      if (ui.tbusy) { toast('Saving, please wait...'); return true; }
      ui.tbusy = true; toast('Saving, please wait...');
      DB.makeLogin('teacher', phone, v('name'), pw, { staffId: tid }).then(function () {
        ui.tbusy = false;
        td.login = true; put('staff', tid, td);
        if (changed) DB.dropLogin('teacher', last10(old.phone));
        closeModal(); render(); toast('Saved.');
      }).catch(function (e) { ui.tbusy = false; toast(authMsg(e)); });
      return true;
    }
    put('staff', tid, td); closeModal(); render(); toast('Saved.'); return true;
  }
  if (k === 'restore') {
    var o = ui.pendingRestore; if (!o) { closeModal(); return true; }
    if (v('word') !== 'RESTORE') { toast('Type RESTORE in capital letters to confirm.'); return true; }
    DB.reauth(v('pw')).then(function () { ui.pendingRestore = null; closeModal(); applyRestore(o); }).catch(function () { toast('Password is wrong.'); });
    return true;
  }
  return false;
}

/* ---------- modals ---------- */
function openModal(html, label) {
  $('#modal').innerHTML = '<div class="veil" data-act="veil"><div class="sheet" role="dialog" aria-modal="true" aria-label="' + esc(label) + '">' + html + '</div></div>';
  limits(); var f = $('#modal input,#modal select'); if (f) f.focus();
}
function closeModal() { $('#modal').innerHTML = ''; }
function head(t) { return '<div class="dates"><h2>' + t + '</h2><button class="btn sm" data-act="close" aria-label="Close">Close</button></div>'; }
function batchOptions(sel) { return S.batches.map(function (b) { return '<option value="' + esc(b.id) + '"' + (b.id === sel ? ' selected' : '') + '>' + esc(b.name) + '</option>'; }).join(''); }
function stuForm(id) {
  var s = id ? stuAny(id) : {}; s = s || {};
  if (!S.batches.length) { openModal(head('Add a student') + '<p>Create a batch first so fees and attendance know where to put this student.</p><button class="btn primary" data-act="batchform">Add a batch</button>', 'Add student'); return; }
  openModal(head(id ? 'Edit student' : 'Add a student') + '<form data-form="student" data-id="' + esc(id || '') + '" class="stack">' +
    '<label>Name<input name="name" required value="' + esc(s.name || '') + '" autocomplete="off"></label>' +
    '<label>Class<input name="cls" required value="' + esc(s.cls || '') + '" placeholder="8" autocomplete="off"></label>' +
    '<label>Batch<select name="batchId">' + batchOptions(s.batchId) + '</select></label>' +
    '<label>Discount % (sibling or scholarship)<input name="disc" type="number" min="0" max="100" step="any" inputmode="decimal" value="' + esc(s.disc || '') + '" placeholder="0"></label>' +
    '<label>Parent name<input name="parent" value="' + esc(s.parent || '') + '" autocomplete="off"></label>' +
    '<label>Parent WhatsApp number<input name="whatsapp" inputmode="tel" value="' + esc(s.whatsapp || '') + '" placeholder="98XXXXXXXX (+977 is added)"></label>' +
    '<label style="flex-direction:row;align-items:center;gap:8px;font-weight:500"><input type="checkbox" name="optout" value="1"' + (s.optout ? ' checked' : '') + ' style="width:20px;min-height:20px;flex:none"> Parent opted out of WhatsApp messages</label>' +
    '<button class="btn primary" type="submit">Save</button>' +
    (id ? '<button class="btn" type="button" data-act="arcstu" data-id="' + esc(id) + '">Archive (student left the centre)</button>' : '') +
    (id ? '<button class="btn danger" type="button" data-act="delstu" data-id="' + esc(id) + '">Delete student</button>' : '') + '</form>', 'Student');
}
function saveStudent(id, v, fd) {
  var sid = id || 's' + uid(), old = id ? stuAny(id) : null;
  var sd = { name: v('name'), cls: v('cls'), batchId: v('batchId'), parent: v('parent'), whatsapp: v('whatsapp'), disc: Math.min(100, Math.max(0, Number(v('disc')) || 0)), optout: !!fd.get('optout') };
  if (old && old.archived) sd.archived = true;
  if (old && old.sample) sd.sample = true;
  if (v('whatsapp') && !validPhone(v('whatsapp'))) { toast('Enter a 10-digit WhatsApp number.'); return; }
    var steps = Promise.resolve();
  steps.then(function () { put('students', sid, sd); closeModal(); render(); toast('Saved.'); }).catch(function (e) { toast(authMsg(e)); });
}
function queue(title, items, note) {
  var skipped = items.filter(function (x) { return x.href === '#optout'; }).length; items = items.filter(function (x) { return x.href !== '#optout'; });
  if (!items.length) { toast(skipped ? 'These parents opted out of WhatsApp.' : 'Nothing to send right now.'); return; }
  note = (note || '') + (skipped ? (note ? ' ' : '') + skipped + ' parent' + (skipped > 1 ? 's' : '') + ' opted out and ' + (skipped > 1 ? 'were' : 'was') + ' skipped.' : '');
  openModal(head(title) + '<p class="muted">Tap Send for each parent. WhatsApp opens with the message ready.</p>' +
    items.map(function (x, i) { return '<div class="row" id="q' + i + '"><div class="grow"><b>' + esc(x.name) + '</b><small>' + esc(x.sub) + '</small></div><a class="btn wa sm" target="_blank" rel="noopener" href="' + esc(x.href) + '" data-act="sentmark" data-q="q' + i + '">' + ic('wa', 18) + 'Send</a></div>'; }).join('') +
    (note ? '<p class="note">' + note + '</p>' : ''), title);
}
function lateQueue() {
  var items = S.fees.filter(function (f) { return !f.paidOn && daysBetween(today, parse(f.due)) > 0 && stu(f.studentId); }).sort(function (a, b) { return daysBetween(today, parse(b.due)) - daysBetween(today, parse(a.due)); }).map(function (f) { var s = stu(f.studentId); return { name: s.name, sub: rs(bal(f)) + ' · ' + daysBetween(today, parse(f.due)) + ' days late', href: waHref(s.whatsapp, msgFee(s, f)) }; });
  queue('Remind late parents', items, 'One WhatsApp chat opens at a time. Sending all at once needs the WhatsApp Business API.');
}
function absentQueue(date) {
  var items = S.students.filter(function (s) { return DB.attDay(s.id, date) === 'A'; }).sort(byName).map(function (s) { return { name: s.name, sub: 'Absent ' + shortDay(date), href: waHref(s.whatsapp, msgAbsent(s, date)) }; });
  queue('Alert absent parents', items);
}
function reportQueue(id) {
  var ts = sortedTests(); var t = get('tests', id) || ts[0]; if (!t) { toast('Add a weekly test first.'); return; }
  var rws = ranked(t);
  queue('Send ' + t.title, rws.map(function (x) { return { name: x.s.name, sub: x.m + '/' + t.max + ' · rank ' + x.rank, href: waHref(x.s.whatsapp, msgReport(x.s, t, x, rws.length, deltaText(deltaFor(t, x.s.id, x.m)))) }; }));
}
function testForm() {
  var ts = sortedTests(); var n = S.tests.length + 1;
  openModal(head('New weekly test') + '<form data-form="test" class="stack">' +
    '<label>Title<input name="title" required value="हप्ता ' + ne(n) + ' को परीक्षा"></label>' +
    '<label>Date (BS, YYYY-MM-DD)<input name="date" required inputmode="numeric" pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" value="' + bsIso(TODAY) + '"></label>' +
    '<label>Maximum marks<input name="max" type="number" min="1" required value="' + (ts[0] ? ts[0].max : 50) + '"></label>' +
    '<div class="marks">' + S.students.slice().sort(byName).map(function (s) { return '<label>' + esc(s.name) + '<input name="m_' + esc(s.id) + '" type="number" min="0" step="any" inputmode="decimal" aria-label="Marks for ' + esc(s.name) + '"></label>'; }).join('') + '</div>' +
    '<button class="btn primary" type="submit">Save test and rank</button></form>', 'New test');
}
function saveTest(title, dt, max, mm) {
  var tid = 't' + uid();
  var list = Object.keys(mm).map(function (k) { return { sid: k, m: mm[k] }; }).sort(function (a, b) { return b.m - a.m; });
  var r = 0, prev = null; list.forEach(function (x, i) { if (x.m !== prev) { r = i + 1; prev = x.m; } x.rank = r; });
  var sum = list.reduce(function (t, x) { return t + x.m; }, 0);
  var jobs = [['set', 'tests', tid, { title: title, date: dt, max: max, avg: list.length ? Math.round(sum / list.length * 10) / 10 : 0, count: list.length }]];
  list.forEach(function (x) { jobs.push(['set', 'marks', tid + '_' + x.sid, { testId: tid, studentId: x.sid, m: x.m, rank: x.rank, n: list.length, date: dt }]); });
  jobs.forEach(function (j) { DB.local(j[1], j[2], j[3]); });
  DB.hooks.audit('tests', tid, 'saved', jobs[0][3]);
  DB.bulkWrite(jobs).catch(fail);
  ui.testId = tid;
}
function batchForm(id) {
  var b = id ? get('batches', id) : {}; b = b || {};
  openModal(head(id ? 'Edit batch' : 'Add a batch') + '<form data-form="batch" data-id="' + esc(id || '') + '" class="stack"><label>Batch name<input name="name" required value="' + esc(b.name || '') + '" placeholder="Class 9 Evening"></label><label>Shift<select name="shift">' + shiftOpts(b.shift) + '</select></label><label>Timing<input name="timing" value="' + esc(b.timing || '') + '" placeholder="5 to 7 pm"></label><label>Teacher<select name="teacherId"><option value="">Not assigned</option>' + S.staff.slice().sort(byName).map(function (t) { return '<option value="' + esc(t.id) + '"' + (t.id === b.teacherId ? ' selected' : '') + '>' + esc(t.name) + '</option>'; }).join('') + '</select></label><label>Monthly fee in rupees<input name="fee" type="number" min="0" required value="' + esc(b.fee == null ? '' : b.fee) + '"></label><button class="btn primary" type="submit">Save batch</button></form>', 'Batch');
}
function enqForm() { openModal(head('New enquiry') + '<form data-form="enq" class="stack"><label>Name<input name="name" required></label><label>WhatsApp number<input name="phone" inputmode="tel"></label><label>Referred by<select name="referredBy"><option value="">Nobody</option>' + S.students.slice().sort(byName).map(function (s) { return '<option value="' + esc(s.id) + '">' + esc(s.name) + '</option>'; }).join('') + '</select></label><button class="btn primary" type="submit">Save enquiry</button></form>', 'Enquiry'); }
function hwForm() {
  if (!S.batches.length) { toast('Add a batch first.'); return; }
  var s = stu(ui.profileId);
  openModal(head('Post homework') + '<form data-form="hw" class="stack"><label>Batch<select name="batchId">' + batchOptions(s && s.batchId) + '</select></label><label>Homework<input name="text" required placeholder="Algebra exercise 4.2, Q1 to 10"></label><label>Due date (BS, YYYY-MM-DD)<input name="due" required inputmode="numeric" pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" value="' + bsIso(iso(addDays(today, 1))) + '"></label><button class="btn primary" type="submit">Post</button></form>', 'Homework');
}
function setForm() { var st = settings(); openModal(head('Centre settings') + '<form data-form="settings" class="stack"><label>Centre name<input name="centre" required value="' + esc(st.centre || '') + '" placeholder="Your Tuition Centre"></label><label>eSewa ID (mobile number)<input name="esewa" inputmode="tel" value="' + esc(st.esewa || '') + '" placeholder="98XXXXXXXX"></label><button class="btn primary" type="submit">Save</button></form>', 'Settings'); }
function receiptModal(id) {
  var f = get('fees', id), s = f && stuAny(f.studentId); if (!s || !f.paidOn) return;
  openModal(head('Fee receipt') + '<div class="receipt"><b>' + esc(centre()) + '</b><span class="muted">Receipt ' + esc(f.rcpt || '') + '</span><hr style="border:0;border-top:1px solid var(--line);width:100%"><span>' + esc(s.name) + ', Class ' + esc(s.cls) + '</span><span class="muted">' + monthLabel(f.month) + ' fees</span><span class="big num">' + rs(f.amount) + '</span><span class="chip good" style="align-self:flex-start">Paid ' + shortDay(f.paidOn) + '</span></div>' +
    '<button class="btn primary" data-act="pdf" data-id="' + esc(id) + '">Download receipt as PDF</button>' + (role() === 'owner' ? '<button class="btn" data-act="unpaid" data-id="' + esc(id) + '">Marked by mistake? Undo payment</button>' : '') +
    '<a class="btn wa" target="_blank" rel="noopener" href="' + esc(waHref(s.whatsapp, msgReceipt(s, f))) + '">' + ic('wa', 18) + 'Send payment notice on WhatsApp</a>' +
    '<p class="note">WhatsApp links cannot attach files. Download the PDF, then attach it in the parent\'s chat.</p>', 'Receipt');
}
/* ---------- PDFs and downloads (drawn on a canvas, wrapped into a PDF by util.jpegPdf) ---------- */
function fitText(g, str, x, y, size, weight, fam, color, maxW, align) {
  var sz = size; g.font = weight + ' ' + sz + 'px ' + fam; while (g.measureText(str).width > maxW && sz > 14) { sz -= 2; g.font = weight + ' ' + sz + 'px ' + fam; }
  g.fillStyle = color; g.textAlign = align || 'left'; g.fillText(str, x, y);
}
function saveBlob(filename, data, mime) {
  var blob = new Blob([data], { type: mime }); var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = filename; document.body.appendChild(a); a.click();
  setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1500); return Promise.resolve();
}
var PAGE = { a5: [419.53, 595.28], a4: [595.28, 841.89] };
function loadFonts() {
  return Promise.all([document.fonts.load('700 40px "Noto Sans Devanagari"', 'शुल्क रसिद'), document.fonts.load('400 30px "Noto Sans Devanagari"', 'मिति'), document.fonts.load('700 40px "Hanken Grotesk"', 'Rs 1500'), document.fonts.load('400 30px "Hanken Grotesk"', 'Receipt')]).catch(function () { });
}
function exportPdf(draw, filename, fmt) {
  loadFonts().then(function () {
    var c = draw(), pg = PAGE[fmt || 'a4'];
    var bytes = U.jpegPdf(U.dataUrlBytes(c.toDataURL('image/jpeg', 0.92)), c.width, c.height, pg[0], pg[1]);
    return saveBlob(filename, bytes, 'application/pdf');
  }).then(function () { toast('PDF saved.'); }).catch(function () { toast('Could not save the PDF. Try again.'); });
}
function drawReceipt(f, s) {
  var W = 1110, H = 1575, c = document.createElement('canvas'); c.width = W; c.height = H; var g = c.getContext('2d');
  var NE = '"Noto Sans Devanagari","Hanken Grotesk",sans-serif', EN = '"Hanken Grotesk","Noto Sans Devanagari",sans-serif';
  var INK = '#12203F', MUT = '#4F5C78', GRN = '#12683F', LINE = '#D6DDEC';
  g.fillStyle = '#FFFFFF'; g.fillRect(0, 0, W, H); g.textBaseline = 'alphabetic';
  g.strokeStyle = INK; g.lineWidth = 4; g.strokeRect(40, 40, W - 80, H - 80);
  fitText(g, centre(), W / 2, 160, 56, '700', EN, INK, W - 200, 'center');
  fitText(g, 'शुल्क रसिद', W / 2, 240, 46, '700', NE, INK, W - 200, 'center');
  fitText(g, 'Fee receipt', W / 2, 285, 28, '400', EN, MUT, W - 200, 'center');
  g.strokeStyle = INK; g.lineWidth = 3; g.beginPath(); g.moveTo(90, 325); g.lineTo(W - 90, 325); g.stroke();
  var b = batchOf(s);
  var rws = [['रसिद नं / Receipt no', f.rcpt || ''], ['विद्यार्थी / Student', s.name], ['कक्षा / Class', String(s.cls) + (b ? ', ' + b.name : '')], ['महिना / Month', monthLabelNe(f.month)], ['भुक्तानी मिति / Paid on', dayLabelNe(f.paidOn)]];
  rws.forEach(function (r, i) {
    var y = 420 + i * 105;
    fitText(g, r[0], 90, y, 30, '400', NE, MUT, 420, 'left');
    fitText(g, r[1], W - 90, y, 36, '700', NE, INK, 520, 'right');
    g.strokeStyle = LINE; g.lineWidth = 2; g.beginPath(); g.moveTo(90, y + 34); g.lineTo(W - 90, y + 34); g.stroke();
  });
  fitText(g, 'रकम / Amount', W / 2, 1000, 32, '400', NE, MUT, W - 200, 'center');
  fitText(g, rsNe(f.amount), W / 2, 1130, 120, '700', NE, INK, W - 200, 'center');
  g.save(); g.translate(W / 2, 1290); g.rotate(-0.08); g.strokeStyle = GRN; g.lineWidth = 6; g.strokeRect(-250, -52, 500, 104);
  fitText(g, 'भुक्तानी प्राप्त / PAID', 0, 14, 40, '700', NE, GRN, 460, 'center'); g.restore();
  fitText(g, 'धन्यवाद! / Thank you.', W / 2, 1470, 34, '400', NE, MUT, W - 200, 'center');
  return c;
}
function downloadReceipt(id) {
  var f = get('fees', id), s = f && stuAny(f.studentId); if (!s || !f.paidOn) return;
  exportPdf(function () { return drawReceipt(f, s); }, 'receipt-' + (f.rcpt || id) + '.pdf', 'a5');
}
function sheet() {
  var W = 1240, H = 1754, c = document.createElement('canvas'); c.width = W; c.height = H; var g = c.getContext('2d');
  g.fillStyle = '#FFFFFF'; g.fillRect(0, 0, W, H); g.textBaseline = 'alphabetic'; g.strokeStyle = '#12203F'; g.lineWidth = 4; g.strokeRect(40, 40, W - 80, H - 80);
  return { W: W, H: H, c: c, g: g, NE: '"Noto Sans Devanagari","Hanken Grotesk",sans-serif', EN: '"Hanken Grotesk","Noto Sans Devanagari",sans-serif', INK: '#12203F', MUT: '#4F5C78', LINE: '#D6DDEC' };
}
function sheetHead(o, ne1, en1) {
  fitText(o.g, centre(), o.W / 2, 150, 60, '700', o.EN, o.INK, o.W - 200, 'center');
  fitText(o.g, ne1, o.W / 2, 230, 50, '700', o.NE, o.INK, o.W - 200, 'center');
  fitText(o.g, en1, o.W / 2, 275, 28, '400', o.EN, o.MUT, o.W - 200, 'center');
  o.g.strokeStyle = o.INK; o.g.lineWidth = 3; o.g.beginPath(); o.g.moveTo(90, 310); o.g.lineTo(o.W - 90, 310); o.g.stroke();
}
function sheetRow(o, label, val, y) {
  fitText(o.g, label, 90, y, 30, '400', o.NE, o.MUT, 520, 'left'); fitText(o.g, val, o.W - 90, y, 38, '700', o.NE, o.INK, 560, 'right');
  o.g.strokeStyle = o.LINE; o.g.lineWidth = 2; o.g.beginPath(); o.g.moveTo(90, y + 30); o.g.lineTo(o.W - 90, y + 30); o.g.stroke();
}
function drawReport(r) {
  var o = sheet(); sheetHead(o, 'मासिक रिपोर्ट', 'Monthly report · ' + monthLabel(r.m));
  fitText(o.g, monthLabelNe(r.m), o.W / 2, 370, 44, '700', o.NE, '#2342C0', o.W - 200, 'center');
  var rws = [['कुल विद्यार्थी / Students', ne(r.students)], ['संकलित शुल्क / Collected', rsNe(r.col)], ['बाँकी शुल्क / Pending', rsNe(r.pen)], ['म्याद नाघेको / Late payments', ne(r.late)], ['उपस्थिति / Attendance', r.att == null ? '-' : ne(r.att) + '%'], ['परीक्षा संख्या / Tests', ne(r.tests)]];
  rws.forEach(function (x, i) { sheetRow(o, x[0], x[1], 470 + i * 100); });
  fitText(o.g, 'उत्कृष्ट विद्यार्थी / Top students', 90, 1180, 34, '700', o.NE, o.INK, o.W - 180, 'left');
  if (!r.top.length) fitText(o.g, 'यस महिना परीक्षा छैन', 90, 1260, 30, '400', o.NE, o.MUT, o.W - 180, 'left');
  r.top.forEach(function (x, i) { sheetRow(o, ne(i + 1) + '. ' + x.s.name, ne(x.pct) + '%', 1260 + i * 100); });
  fitText(o.g, 'मिति: ' + dayLabelNe(TODAY), o.W / 2, 1690, 28, '400', o.NE, o.MUT, o.W - 200, 'center');
  return o.c;
}
function drawCard(s) {
  var o = sheet(); sheetHead(o, 'प्रगति पत्र', 'Progress card'); var g = o.g, W = o.W, b = batchOf(s), pc = attPct(s.id);
  [['विद्यार्थी / Student', s.name], ['कक्षा / Class', String(s.cls) + (b ? ', ' + b.name : '')], ['उपस्थिति / Attendance', pc == null ? '-' : ne(pc) + '%']].forEach(function (x, i) { sheetRow(o, x[0], x[1], 400 + i * 95); });
  var y = 720; [['परीक्षा', 90, 'left'], ['प्राप्ताङ्क', 780, 'right'], ['प्रतिशत', 940, 'right'], ['स्थान', W - 90, 'right']].forEach(function (h) { fitText(g, h[0], h[1], y, 28, '700', o.NE, o.MUT, 300, h[2]); });
  g.strokeStyle = o.INK; g.lineWidth = 2; g.beginPath(); g.moveTo(90, y + 22); g.lineTo(W - 90, y + 22); g.stroke();
  var rws = studentTests(s.id).slice(0, 8);
  if (!rws.length) fitText(g, 'परीक्षाको विवरण छैन', 90, y + 90, 30, '400', o.NE, o.MUT, W - 180, 'left');
  rws.forEach(function (x, i) {
    var yy = y + 90 + i * 85;
    fitText(g, x.t.title, 90, yy, 32, '400', o.NE, o.INK, 560, 'left');
    fitText(g, ne(x.r.m) + '/' + ne(x.t.max), 780, yy, 32, '700', o.NE, o.INK, 200, 'right');
    fitText(g, ne(Math.round(x.r.m / x.t.max * 100)) + '%', 940, yy, 32, '400', o.NE, o.INK, 140, 'right');
    fitText(g, ne(x.r.rank), W - 90, yy, 32, '700', o.NE, o.INK, 120, 'right');
    g.strokeStyle = o.LINE; g.lineWidth = 2; g.beginPath(); g.moveTo(90, yy + 26); g.lineTo(W - 90, yy + 26); g.stroke();
  });
  g.strokeStyle = o.INK; g.lineWidth = 2; g.beginPath(); g.moveTo(120, 1580); g.lineTo(420, 1580); g.moveTo(W - 420, 1580); g.lineTo(W - 120, 1580); g.stroke();
  fitText(g, 'शिक्षक', 270, 1625, 28, '400', o.NE, o.MUT, 260, 'center'); fitText(g, 'अभिभावक', W - 270, 1625, 28, '400', o.NE, o.MUT, 260, 'center');
  fitText(g, 'मिति: ' + dayLabelNe(TODAY), W / 2, 1695, 26, '400', o.NE, o.MUT, W - 200, 'center');
  return o.c;
}
function csvCell(x) { x = String(x == null ? '' : x); if (/^[=+\-@\t\r]/.test(x) && !/^-?\d+(\.\d+)?$/.test(x)) x = "'" + x; return /[",\n]/.test(x) ? '"' + x.replace(/"/g, '""') + '"' : x; }
function exportCsv(name, rws) { var txt = '﻿' + rws.map(function (r) { return r.map(csvCell).join(','); }).join('\r\n'); saveBlob(name, new TextEncoder().encode(txt), 'text/csv').then(function () { toast('File saved.'); }); }
function exportStudents() { var r = [['Name', 'Class', 'Batch', 'Parent', 'WhatsApp', 'Discount %']]; S.students.slice().sort(byName).forEach(function (s) { var b = batchOf(s); r.push([s.name, s.cls, b ? b.name : '', s.parent || '', s.whatsapp || '', s.disc || 0]); }); exportCsv('students.csv', r); }
function exportFees() { var r = [['Student', 'Class', 'Batch', 'Month (BS)', 'Amount', 'Paid so far', 'Balance', 'Due date (BS)', 'Status', 'Paid on (BS)', 'Receipt']]; S.fees.slice().sort(function (a, b) { return String(b.month).localeCompare(String(a.month)); }).forEach(function (f) { var s = stu(f.studentId); if (!s) return; var b = batchOf(s); r.push([s.name, s.cls, b ? b.name : '', monthLabel(f.month), f.amount, f.paidOn ? f.amount : (f.part || 0), f.paidOn ? 0 : bal(f), bsIso(f.due), f.paidOn ? 'Paid' : (f.due < TODAY ? 'Late' : 'Due'), f.paidOn ? bsIso(f.paidOn) : '', f.rcpt || '']); }); exportCsv('fees.csv', r); }

/* ---------- notices, weak alerts, monthly report, profile ---------- */
var KIND = { holiday: { en: 'Holiday', ne: 'बिदा', em: '🏖️' }, exam: { en: 'Exam', ne: 'परीक्षा', em: '📝' }, general: { en: 'Notice', ne: 'सूचना', em: '📢' } };
function msgNotice(s, n) {
  var K = KIND[n.kind] || KIND.general;
  return greet(s) + NL + NL + K.em + ' *' + K.ne + '*' + NL + '━━━━━━━━━━━━━━' + NL + n.text + (n.date ? NL + '📅 मिति: ' + dayLabelNe(n.date) : '') + NL + '━━━━━━━━━━━━━━' + NL + 'धन्यवाद! 🙏' + foot();
}
function msgWeak(s, rl) {
  return greet(s) + NL + NL + '⚠️ *ध्यानाकर्षण*' + NL + '━━━━━━━━━━━━━━' + NL + '👤 विद्यार्थी: *' + s.name + '*' + NL + rl.map(function (r) { return '• ' + r.ne; }).join(NL) + NL + '━━━━━━━━━━━━━━' + NL + 'कृपया पढाइमा थप ध्यान दिन सहयोग गर्नुहोला। 🙏' + foot();
}
function weakList() {
  return S.students.map(function (s) {
    var rl = [], pc = attPct(s.id), c = attCounts(s.id), n = c.p + c.a;
    if (pc != null && n >= 3 && pc < 75) rl.push({ en: 'Attendance ' + pc + '%', ne: 'उपस्थिति ' + ne(pc) + '% मात्र छ' });
    var pts = studentTests(s.id).map(function (x) { return Math.round(x.r.m / x.t.max * 100); });
    if (pts.length && pts[0] < 40) rl.push({ en: 'Last test ' + pts[0] + '%', ne: 'पछिल्लो परीक्षामा ' + ne(pts[0]) + '% अङ्क' });
    if (pts.length > 1 && pts[1] - pts[0] >= 15) rl.push({ en: 'Marks down ' + (pts[1] - pts[0]) + '%', ne: 'अघिल्लो परीक्षाभन्दा ' + ne(pts[1] - pts[0]) + '% कमी' });
    return { s: s, r: rl };
  }).filter(function (x) { return x.r.length; });
}
function repMonths() { var o = {}; S.fees.forEach(function (f) { o[f.month] = 1; }); var k = Object.keys(o).sort().reverse(); var m0 = monthKey(today); if (k.indexOf(m0) < 0) k.unshift(m0); return k; }
function reportData(m) {
  var fm = S.fees.filter(function (f) { return f.month === m && stu(f.studentId); });
  var col = 0, pen = 0, late = 0;
  fm.forEach(function (f) { if (f.paidOn) col += Number(f.amount); else { col += Number(f.part || 0); pen += bal(f); if (f.due < TODAY) late++; } });
  var p = 0, a = 0;
  S.att.forEach(function (r) { if (!stu(r.studentId)) return; var d = r.days || {}; Object.keys(d).forEach(function (k) { if (monthKey(parse(k)) !== m) return; if (d[k] === 'P') p++; else if (d[k] === 'A') a++; }); });
  var tt2 = S.tests.filter(function (t) { return monthKey(parse(t.date)) === m; });
  var top = S.students.map(function (s) { var sum = 0, n = 0; tt2.forEach(function (t) { var mk = DB.markOf(t.id, s.id); if (mk) { sum += Number(mk.m) / t.max * 100; n++; } }); return { s: s, pct: n ? Math.round(sum / n) : null }; }).filter(function (x) { return x.pct != null; }).sort(function (x, y) { return y.pct - x.pct; }).slice(0, 3);
  return { m: m, col: col, pen: pen, late: late, att: p + a ? Math.round(p / (p + a) * 100) : null, top: top, tests: tt2.length, students: S.students.length };
}
function hasSample() { return ALLSTU.some(function (s) { return s.sample; }); }
function dashExtras() {
  var h = '', K = KIND;
  var ns = S.notices.slice().sort(function (a, b) { return String(b.created || '').localeCompare(String(a.created || '')); });
  h += '<div class="card"><div class="dates"><h2>Notices and holidays</h2><button class="btn sm" data-act="noticeform">' + ic('plus', 18) + 'Add</button></div>' +
    (ns.length ? ns.map(function (n) { return '<div class="row" style="flex-wrap:wrap"><div class="grow"><b>' + esc(n.text) + '</b><small>' + (K[n.kind] || K.general).en + (n.date ? ' · ' + shortDay(n.date) : '') + '</small></div><div class="wrap" style="flex:none"><button class="btn wa sm" data-act="noticeq" data-id="' + esc(n.id) + '">Send to all</button><button class="btn danger sm" data-act="delnotice" data-id="' + esc(n.id) + '" aria-label="Delete notice">Delete</button></div></div>'; }).join('') : '<p class="muted">Add a holiday, exam date or notice, then send it to every parent in Nepali. Parents also see it in their app.</p>') + '</div>';
  var wk = weakList();
  h += '<div class="card"><h2>Needs attention</h2>' + (wk.length ? wk.map(function (x) { return '<div class="row">' + av(x.s.name) + '<div class="grow"><b>' + esc(x.s.name) + '</b><small>' + x.r.map(function (r) { return r.en; }).join(' · ') + '</small></div><a class="btn wa sm" target="_blank" rel="noopener" href="' + esc(waHref(x.s.whatsapp, msgWeak(x.s, x.r))) + '">' + ic('wa', 18) + 'Alert</a></div>'; }).join('') : '<p class="muted">Nobody needs attention right now. Attendance below 75% or a weak test result shows up here.</p>') + '</div>';
  var ms = repMonths(); if (!ui.repMonth || ms.indexOf(ui.repMonth) < 0) ui.repMonth = ms[0];
  var r = reportData(ui.repMonth);
  h += '<div class="card"><h2>Monthly report</h2><label>Month<select data-change="repm">' + ms.map(function (m) { return '<option value="' + esc(m) + '"' + (m === ui.repMonth ? ' selected' : '') + '>' + monthLabel(m) + '</option>'; }).join('') + '</select></label>' +
    '<div class="tiles"><div class="tile"><b style="font-size:18px">' + rs(r.col) + '</b><small>collected</small></div><div class="tile"><b style="font-size:18px">' + rs(r.pen) + '</b><small>pending</small></div><div class="tile"><b>' + (r.att == null ? '-' : r.att + '%') + '</b><small>attendance</small></div></div>' +
    (r.top.length ? '<div>' + r.top.map(function (x, i) { return '<div class="row"><div class="rank ' + (i === 0 ? 'top1' : '') + '">' + (i + 1) + '</div><div class="grow"><b>' + esc(x.s.name) + '</b></div><b class="num">' + x.pct + '%</b></div>'; }).join('') + '</div>' : '<p class="muted">No tests in this month.</p>') +
    '<button class="btn primary block" data-act="repdl">Download report as PDF</button></div>';
  h += '<div class="card"><h2>Export to Excel (CSV)</h2><p class="muted">Download your data as CSV files. They open in Excel and Google Sheets.</p><div class="wrap"><button class="btn" data-act="expstu">Students (CSV)</button><button class="btn" data-act="expfee">Fees (CSV)</button></div></div>';
  if (hasSample()) h += '<div class="card"><h2>Sample data</h2><p class="muted">The sample students, fees, marks and homework are still here. Remove them before you start with real students.</p><button class="btn danger" data-act="rmsample">Remove sample data</button></div>';
  return h;
}
function profileModal(id) {
  var s = stu(id); if (!s) return; var b = batchOf(s), pc = attPct(id);
  var fees = S.fees.filter(function (f) { return f.studentId === id; }).sort(function (a, b2) { return String(b2.month).localeCompare(String(a.month)); });
  var pend = fees.reduce(function (t, f) { return t + (f.paidOn ? 0 : bal(f)); }, 0);
  var rws = studentTests(id);
  openModal(head('Student profile') + '<div class="row" style="border:0;padding:0">' + av(s.name) + '<div class="grow"><b>' + esc(s.name) + '</b><small>Class ' + esc(s.cls) + (b ? ' · ' + esc(b.name) : '') + '</small></div></div>' +
    '<div class="tiles"><div class="tile"><b>' + (pc == null ? '-' : pc + '%') + '</b><small>attendance</small></div><div class="tile"><b>' + (s.disc || 0) + '%</b><small>discount</small></div><div class="tile"><b style="font-size:17px">' + rs(pend) + '</b><small>pending</small></div></div>' +
    '<div><h2>Fees</h2>' + (fees.length ? fees.map(function (f) { return '<div class="row"><div class="grow"><b>' + monthLabel(f.month) + '</b><small>' + (f.paidOn ? 'Paid ' + shortDay(f.paidOn) : 'Due ' + shortDay(f.due)) + '</small></div><b class="num">' + rs(f.amount) + '</b><span class="chip ' + (f.paidOn ? 'good' : (f.due < TODAY ? 'late' : 'warn')) + '">' + (f.paidOn ? 'Paid' : rs(bal(f)) + ' left') + '</span></div>'; }).join('') : '<p class="muted">No fees yet.</p>') + '</div>' +
    '<div><h2>Tests</h2>' + (rws.length ? rws.slice(0, 6).map(function (x) { return '<div class="row"><div class="grow"><b>' + esc(x.t.title) + '</b><small>' + shortDay(x.t.date) + '</small></div><b class="num">' + x.r.m + '/' + x.t.max + '</b><span class="chip">Rank ' + x.r.rank + '</span></div>'; }).join('') : '<p class="muted">No test marks yet.</p>') + '</div>' +
    '<button class="btn primary block" data-act="pdfcard" data-id="' + esc(id) + '">Download progress card (PDF)</button><button class="btn block" data-act="stuform" data-id="' + esc(id) + '">Edit student</button>', 'Student profile');
}

/* ---------- sample data (all marked sample so it can be removed) ---------- */
function buildSeed() {
  var J = [], m0 = monthKey(today), m1 = prevKey(m0), SM = { sample: true };
  var add = function (c, id, d) { J.push([c, id, Object.assign({}, d, SM)]); };
  var B = [['smp_b1', 'Class 8 Morning', '7 to 9 am', 1500], ['smp_b2', 'Class 9 Evening', '5 to 7 pm', 1800], ['smp_b3', 'Class 10 Evening', '7 to 9 pm', 2200]];
  B.forEach(function (b) { add('batches', b[0], { name: b[1], timing: b[2], fee: b[3] }); });
  var N = ['Aarav Sharma', 'Diya Verma', 'Kabir Singh', 'Ananya Gupta', 'Rohan Mehta', 'Ishita Joshi', 'Vihaan Yadav', 'Saanvi Patel', 'Arjun Mishra', 'Meera Nair', 'Reyansh Kumar', 'Tara Iyer'];
  var ids = [];
  N.forEach(function (n, i) { var id = 'smp_s' + p2(i + 1); ids.push(id); var bi = Math.floor(i / 4); add('students', id, { name: n, cls: String(8 + bi), batchId: B[bi][0], parent: n.split(' ')[1] + ' ज्यू', whatsapp: '00000000' + p2(i + 1), disc: 0, optout: false, login: false }); });
  var late1 = [2, 9], late0 = [2, 5, 7, 9, 11], rc = 0;
  N.forEach(function (n, i) {
    var fee = B[Math.floor(i / 4)][3];
    var f1 = late1.indexOf(i) < 0; add('fees', ids[i] + '_' + m1, { studentId: ids[i], month: m1, amount: fee, due: keyDay(m1, 5), paidOn: f1 ? keyDay(m1, 3 + i % 3) : null, rcpt: f1 ? 'R' + m1.replace('-', '') + '-S' + ('00' + (++rc)).slice(-3) : null });
    var f0 = late0.indexOf(i) < 0; var pd = keyDay(m0, 2 + i % 3); if (pd > TODAY) pd = TODAY;
    add('fees', ids[i] + '_' + m0, { studentId: ids[i], month: m0, amount: fee, due: keyDay(m0, 5), paidOn: f0 ? pd : null, rcpt: f0 ? 'R' + m0.replace('-', '') + '-S' + ('00' + (++rc)).slice(-3) : null });
  });
  var days = {}; ids.forEach(function (id) { days[id] = {}; });
  for (var k = 1; k <= 8; k++) { var d = addDays(today, -k); if (d.getDay() === 6) continue; ids.forEach(function (id, i) { days[id][iso(d)] = ((i * 7 + k * 3) % 11 === 0) ? 'A' : 'P'; }); }
  ids.forEach(function (id) {
    var byMonth = {}; Object.keys(days[id]).forEach(function (dt) { var mk = monthKey(parse(dt)); (byMonth[mk] = byMonth[mk] || {})[dt] = days[id][dt]; });
    Object.keys(byMonth).forEach(function (mk) { add('att', id + '_' + mk, { studentId: id, month: mk, days: byMonth[mk] }); });
  });
  [3, 2, 1].forEach(function (w, wi) {
    var dt = iso(addDays(today, -7 * (w - 1))), tid = 'smp_t' + (wi + 1), list = [];
    ids.forEach(function (id, i) { list.push({ sid: id, m: Math.min(50, 18 + ((i * 13 + wi * 7 + w * 5) % 30)) }); });
    list.sort(function (a, b) { return b.m - a.m; }); var r = 0, prev = null, sum = 0;
    list.forEach(function (x, i) { if (x.m !== prev) { r = i + 1; prev = x.m; } x.rank = r; sum += x.m; });
    add('tests', tid, { title: 'हप्ता ' + ne(wi + 1) + ' को परीक्षा', date: dt, max: 50, avg: Math.round(sum / list.length * 10) / 10, count: list.length });
    list.forEach(function (x) { add('marks', tid + '_' + x.sid, { testId: tid, studentId: x.sid, m: x.m, rank: x.rank, n: list.length, date: dt }); });
  });
  add('enquiries', 'smp_e1', { name: 'Neha Kapoor', phone: '0000000101', referredBy: ids[0], date: iso(addDays(today, -2)), status: 'new' });
  add('enquiries', 'smp_e2', { name: 'Samar Khan', phone: '0000000102', referredBy: ids[5], date: iso(addDays(today, -5)), status: 'contacted' });
  add('enquiries', 'smp_e3', { name: 'Pooja Rao', phone: '0000000103', referredBy: ids[8], date: iso(addDays(today, -9)), status: 'joined' });
  B.forEach(function (b, i) {
    add('homework', 'smp_h' + (i * 2 + 1), { batchId: b[0], text: ['Fractions worksheet 3', 'Algebra exercise 4.2, Q1 to 10', 'Quadratic equations, set B'][i], due: iso(addDays(today, 1)) });
    add('homework', 'smp_h' + (i * 2 + 2), { batchId: b[0], text: ['Reading passage and 5 questions', 'Newton\'s laws, short notes', 'Trigonometry identities, Q1 to 8'][i], due: iso(addDays(today, -2)) });
  });
  return J;
}
function seed() {
  if (ui.seeding) return; ui.seeding = true; toast('Loading sample data...');
  var jobs = buildSeed().map(function (j) { return ['set', j[0], j[1], j[2]]; });
  jobs.forEach(function (j) { DB.local(j[1], j[2], j[3]); }); render();
  DB.bulkWrite(jobs).then(function () { ui.seeding = false; logEv('Sample data loaded'); toast('Sample data loaded.'); }).catch(function (e) { ui.seeding = false; fail(e); });
}
function removeSample() {
  var jobs = [];
  ['students', 'batches', 'fees', 'att', 'tests', 'marks', 'enquiries', 'homework'].forEach(function (c) { rows(c).filter(function (x) { return x.sample; }).forEach(function (x) { jobs.push(['del', c, x.id]); }); });
  jobs.forEach(function (j) { var R = rows(j[1]), i = R.findIndex(function (x) { return x.id === j[2]; }); if (i >= 0) R.splice(i, 1); });
  DB.reindex(); render();
  DB.bulkWrite(jobs).then(function () { logEv('Sample data removed'); toast('Sample data removed.'); }).catch(fail);
}

/* ---------- actions ---------- */
function confirmPaid(id) {
  var f = get('fees', id), s = f && stuAny(f.studentId); if (!f || !s || f.paidOn) return;
  openModal(head('Mark as paid?') + '<div class="receipt"><span>' + esc(s.name) + ', Class ' + esc(s.cls) + '</span><span class="muted">' + monthLabel(f.month) + ' fees</span><span class="big num">' + rs(bal(f)) + '</span></div><p class="note">This records the full fee as received and creates a receipt. Tap Cancel if you pressed by mistake.</p>' +
    '<button class="btn primary" data-act="paidyes" data-id="' + esc(id) + '">Yes, mark paid</button><button class="btn" data-act="close">Cancel</button>', 'Confirm');
}
function confirmUnpaid(id) {
  var f = get('fees', id), s = f && stuAny(f.studentId); if (!f || !s || !f.paidOn) return;
  openModal(head('Undo this payment?') + '<div class="receipt"><span>' + esc(s.name) + '</span><span class="muted">' + monthLabel(f.month) + ' fees</span><span class="big num">' + rs(f.amount) + '</span></div><p class="note">The fee goes back to pending. The receipt number is kept, so the same number is used if you mark it paid again.</p>' +
    '<button class="btn primary" data-act="unpaidyes" data-id="' + esc(id) + '">Yes, undo payment</button><button class="btn" data-act="close">Keep it paid</button>', 'Confirm');
}
function unmarkPaid(id) {
  var f = get('fees', id); if (!f) return;
  patch('fees', id, { paidOn: '', part: 0 });
  closeModal(); toast('Payment undone. Fee is pending again.'); render();
}
function markPaid(id) {
  var f = get('fees', id); if (!f || f.paidOn) return;
  patch('fees', id, { paidOn: TODAY, part: Number(f.amount), rcpt: f.rcpt || newReceipt(f.month) });
  toast('Marked paid. Receipt ready.'); receiptModal(id); render();
}
function loadAttMonth() { DB.ensureAttMonth(monthKey(parse(ui.date))).then(function () { render(); }); }
document.addEventListener('click', function (e) {
  var oa = e.target.closest('a[href="#optout"]'); if (oa) { e.preventDefault(); toast('This parent opted out of WhatsApp messages.'); return; }
  var tb = e.target.closest('[data-tab]');
  if (tb) { ui.tab = tb.getAttribute('data-tab'); render(); window.scrollTo(0, 0); return; }
  var el = e.target.closest('[data-act]'); if (!el) return;
  var a = el.getAttribute('data-act'), id = el.getAttribute('data-id');
  var rl0 = role();
  if (a === 'reload') { location.reload(); return; }
  if (!rl0 && UNAUTH.indexOf(a) < 0) return;
  if (rl0 && rl0 !== 'owner' && ALLOW[rl0].indexOf(a) < 0) return;
  if (a === 'logout') return logout();
  if (a === 'lrole') { ui.lrole = el.getAttribute('data-v'); render(); return; }
  if (a === 'chpw') return chpwModal();
  if (a === 'showpw') { var fm = el.closest('form'); if (fm) fm.querySelectorAll('input[data-pw]').forEach(function (i) { i.type = el.checked ? 'text' : 'password'; }); return; }
  if (a === 'privacy') return privacyModal();
  if (a === 'forgot') return forgotModal();
  if (a === 'teacherform') return teacherForm(id);
  if (a === 'delteacher') {
    if (!el.getAttribute('data-armed')) { el.setAttribute('data-armed', '1'); el.textContent = 'Tap again to remove'; return; }
    var tc = get('staff', id); if (tc && tc.phone) DB.dropLogin('teacher', last10(tc.phone)).catch(function () { });
    shiftsOf(id).forEach(function (b) { patch('batches', b.id, { teacherId: '' }); }); remove('staff', id); closeModal(); toast('Teacher removed.'); render(); return;
  }
  if (a === 'arcstu') {
    var as = stuAny(id);
    if (as) { patch('students', id, { archived: true }); logEv('Student ' + as.name + ' archived'); }
    closeModal(); toast('Student archived.'); render(); return;
  }
  if (a === 'unarc') {
    var us = stuAny(id);
    if (us) { put('students', id, Object.assign(strip(us), { archived: false })); logEv('Student ' + us.name + ' restored'); }
    toast('Student restored.'); render(); return;
  }
  if (a === 'paysalary') { var t0 = get('staff', id); if (!t0) return; var sm = monthKey(today); put('salary', id + '_' + sm, { staffId: id, month: sm, amount: payDue(t0), shifts: shiftsOf(id).length, paidOn: TODAY }); toast('Pay marked as paid.'); render(); return; }
  if (a === 'unpaysalary') { remove('salary', id + '_' + monthKey(today)); render(); return; }
  if (a === 'claimno') { patch('claims', id, { status: 'rejected', decided: TODAY }); toast('Rejected.'); render(); return; }
  if (a === 'bakdl') return doBackup();
  if (a === 'veil') { if (e.target === el) closeModal(); return; }
  if (a === 'close') { closeModal(); return; }
  if (a === 'sentmark') { var r = document.getElementById(el.getAttribute('data-q')); if (r) r.classList.add('sent'); return; }
  if (a === 'seed') return seed();
  if (a === 'rmsample') {
    if (!el.getAttribute('data-armed')) { el.setAttribute('data-armed', '1'); el.textContent = 'Tap again to remove'; return; }
    return removeSample();
  }
  if (a === 'genfees') {
    var m0 = monthKey(today), jobs = [];
    S.students.forEach(function (s) { if (S.fees.some(function (f) { return f.studentId === s.id && f.month === m0; })) return; var b = batchOf(s); if (!b) return; jobs.push(['set', 'fees', s.id + '_' + m0, { studentId: s.id, month: m0, amount: Math.round(Number(b.fee) * (100 - (Number(s.disc) || 0)) / 100), due: keyDay(m0, 5), paidOn: null, rcpt: null }]); });
    jobs.forEach(function (j) { DB.local(j[1], j[2], j[3]); });
    DB.bulkWrite(jobs).catch(fail); logEv('Created monthly fees (' + jobs.length + ')');
    toast(jobs.length + ' fees created for ' + monthLabel(m0) + '.'); render(); return;
  }
  if (a === 'remindq') return lateQueue();
  if (a === 'absentq') return absentQueue(el.getAttribute('data-auto') ? TODAY : ui.date);
  if (a === 'reportq') return reportQueue(id);
  if (a === 'paid') return confirmPaid(id);
  if (a === 'paidyes') return markPaid(id);
  if (a === 'unpaid') return confirmUnpaid(id);
  if (a === 'unpaidyes') return unmarkPaid(id);
  if (a === 'receipt') return receiptModal(id);
  if (a === 'pdf') return downloadReceipt(id);
  if (a === 'partform') return partForm(id);
  if (a === 'profile') return profileModal(id);
  if (a === 'pdfcard') { var sc = stu(id); return exportPdf(function () { return drawCard(sc); }, 'progress-card-' + String(sc.name).replace(/\s+/g, '-') + '.pdf', 'a4'); }
  if (a === 'ffilter') { ui.ff = el.getAttribute('data-v'); render(); return; }
  if (a === 'noticeform') return noticeForm();
  if (a === 'noticeq') return noticeQueue(id);
  if (a === 'delnotice') { remove('notices', id); render(); return; }
  if (a === 'repdl') { var r0 = reportData(ui.repMonth); return exportPdf(function () { return drawReport(r0); }, 'monthly-report-' + r0.m + '.pdf', 'a4'); }
  if (a === 'expstu') { logEv('Exported students CSV'); return exportStudents(); }
  if (a === 'expfee') { logEv('Exported fees CSV'); return exportFees(); }
  if (a === 'copy') { var v0 = el.getAttribute('data-v'); try { navigator.clipboard.writeText(v0).then(function () { toast('Copied.'); }, function () { toast('Copy failed. Select the ID and copy it.'); }); } catch (x) { toast('Copy failed. Select the ID and copy it.'); } return; }
  if (a === 'dprev') { ui.date = iso(addDays(parse(ui.date), -1)); render(); loadAttMonth(); return; }
  if (a === 'dnext') { if (ui.date < TODAY) { ui.date = iso(addDays(parse(ui.date), 1)); render(); loadAttMonth(); } return; }
  if (a === 'batch') { ui.batch = id; render(); return; }
  if (a === 'att') { DB.setAtt(id, ui.date, el.getAttribute('data-v')); render(); return; }
  if (a === 'allp') { DB.bulkAtt(S.students.filter(function (s) { return ui.batch === 'all' || s.batchId === ui.batch; }).map(function (s) { return s.id; }), ui.date, 'P'); render(); return; }
  if (a === 'test') { ui.testId = id; render(); return; }
  if (a === 'testform') return testForm();
  if (a === 'stuform') return stuForm(id);
  if (a === 'batchform') return batchForm(id);
  if (a === 'sfilter') { ui.sf = el.getAttribute('data-v'); render(); return; }
  if (a === 'shiftedit') return shiftForm(id);
  if (a === 'shiftstu') return shiftStudents(id);
  if (a === 'enqform') return enqForm();
  if (a === 'hwform') return hwForm();
  if (a === 'setform') return setForm();
  if (a === 'enqstatus') { var e0 = get('enquiries', id); var o = ['new', 'contacted', 'joined']; patch('enquiries', id, { status: o[(o.indexOf(e0.status) + 1) % 3] }); render(); return; }
  if (a === 'delstu') {
    if (!el.getAttribute('data-armed')) { el.setAttribute('data-armed', '1'); el.textContent = 'Tap again to delete'; return; }
    S.fees.filter(function (f) { return f.studentId === id; }).forEach(function (f) { remove('fees', f.id); });
    S.att.filter(function (x) { return x.studentId === id; }).forEach(function (x) { DB.unlocal('att', x.id); DB.removeRemote('att', x.id); });
    S.marks.filter(function (x) { return x.studentId === id; }).forEach(function (x) { DB.unlocal('marks', x.id); DB.removeRemote('marks', x.id); });
    remove('students', id); closeModal(); toast('Student deleted.'); render(); return;
  }
});
function partForm(id) { var f = get('fees', id), s = f && stu(f.studentId); if (!s) return; var bl = bal(f); openModal(head('Part payment') + '<p class="muted">' + esc(s.name) + ' · ' + monthLabel(f.month) + ' · balance ' + rs(bl) + '</p><form data-form="part" data-id="' + esc(id) + '" class="stack"><label>Amount received (Rs)<input name="amt" type="number" min="1" max="' + bl + '" step="any" inputmode="decimal" required></label><button class="btn primary" type="submit">Save payment</button></form>', 'Part payment'); }
function noticeForm() { openModal(head('New notice') + '<form data-form="notice" class="stack"><label>Type<select name="kind"><option value="holiday">Holiday</option><option value="exam">Exam</option><option value="general">Notice</option></select></label><label>Message<input name="text" required placeholder="Tomorrow is a holiday for Dashain"></label><label>Date (BS, YYYY-MM-DD, optional)<input name="date" inputmode="numeric" placeholder="2083-07-08"></label><button class="btn primary" type="submit">Save notice</button></form>', 'Notice'); }
function noticeQueue(id) { var n = get('notices', id); if (!n) return; queue('Send notice', S.students.slice().sort(byName).map(function (s) { return { name: s.name, sub: s.parent || 'Parent', href: waHref(s.whatsapp, msgNotice(s, n)) }; }), 'Parents with no number will open an empty chat.'); }
document.addEventListener('change', function (e) {
  var fl = e.target.closest('[data-file="restore"]'); if (fl) { if (role() === 'owner') readRestore(fl.files && fl.files[0]); fl.value = ''; return; }
  var rm = e.target.closest('[data-change="repm"]'); if (rm) { ui.repMonth = rm.value; render(); DB.ensureAttMonth(rm.value).then(function () { render(); }); }
});
document.addEventListener('input', function (e) {
  var sm = e.target.closest('[data-strength]'); if (sm) { meter(sm); return; }
  var el = e.target.closest('[data-search]'); if (!el) return;
  var k = el.getAttribute('data-search'), pos = el.selectionStart; ui[k] = el.value; render();
  var n = document.querySelector('[data-search="' + k + '"]'); if (n) { n.focus(); try { n.setSelectionRange(pos, pos); } catch (x) { } }
});
document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeModal(); });
document.addEventListener('submit', function (e) {
  var f = e.target.closest('form[data-form]'); if (!f) return; e.preventDefault();
  var k = f.getAttribute('data-form'), id = f.getAttribute('data-id'), fd = new FormData(f), v = function (n) { return String(fd.get(n) == null ? '' : fd.get(n)).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '').trim().slice(0, 500); };
  var rl = role(), okk = !rl ? ['setup', 'login', 'forgot'] : rl === 'teacher' ? ['test', 'hw', 'shift'] : null;
  if (okk && okk.indexOf(k) < 0) return;
  ui.formId = id; if (authSubmit(k, v)) return;
  if (k === 'student') { saveStudent(id, v, fd); return; }
  else if (k === 'batch') { var bo = id ? get('batches', id) : null; put('batches', id || 'b' + uid(), Object.assign(bo ? strip(bo) : {}, { name: v('name'), timing: v('timing'), fee: Number(v('fee')), shift: SHIFT[v('shift')] ? v('shift') : 'morning', teacherId: v('teacherId') })); }
  else if (k === 'shift') { var sb = get('batches', id); if (!sb) { closeModal(); return; } patch('batches', id, { shift: SHIFT[v('shift')] ? v('shift') : 'morning', timing: v('timing'), teacherId: v('teacherId') }); }
  else if (k === 'enq') { put('enquiries', 'e' + uid(), { name: v('name'), phone: v('phone'), referredBy: v('referredBy'), date: TODAY, status: 'new' }); }
  else if (k === 'hw') { var due = parseBS(v('due')); if (!due) { toast('Enter the due date in BS as YYYY-MM-DD, for example 2083-07-07.'); return; } put('homework', 'h' + uid(), { batchId: v('batchId'), text: v('text'), due: due }); }
  else if (k === 'part') {
    var f0 = get('fees', id);
    if (f0) {
      var add = Number(v('amt')), np = Number(f0.part || 0) + add; if (!(add > 0)) { toast('Enter an amount.'); return; }
      if (np >= Number(f0.amount)) { patch('fees', id, { part: Number(f0.amount), paidOn: TODAY, rcpt: f0.rcpt || newReceipt(f0.month) }); closeModal(); render(); receiptModal(id); toast('Fully paid. Receipt ready.'); return; }
      patch('fees', id, { part: np }); closeModal(); render(); toast(rs(add) + ' saved. Balance ' + rs(Number(f0.amount) - np) + '.'); return;
    }
  }
  else if (k === 'notice') { var nd = v('date') ? parseBS(v('date')) : ''; if (v('date') && !nd) { toast('Enter the date in BS as YYYY-MM-DD, for example 2083-07-08.'); return; } put('notices', 'n' + uid(), { text: v('text'), kind: v('kind'), date: nd || '', created: TODAY }); }
  else if (k === 'settings') { patch('settings', 'main', { centre: v('centre'), esewa: v('esewa') }); DB.setInfo(v('centre')).catch(function () { }); ui.info = { centre: v('centre') }; }
  else if (k === 'test') {
    var dt = parseBS(v('date')); if (!dt) { toast('Enter the date in BS as YYYY-MM-DD, for example 2083-07-06.'); return; }
    var mx = Number(v('max')); if (!(mx > 0)) { toast('Enter the maximum marks.'); return; }
    var mm = {}; var bad = false;
    S.students.forEach(function (s) { var x = v('m_' + s.id); if (x !== '') { var n = Number(x); if (!(n >= 0) || n > mx) bad = true; mm[s.id] = n; } });
    if (bad) { toast('Marks must be between 0 and ' + mx + '.'); return; }
    if (!Object.keys(mm).length) { toast('Enter marks for at least one student.'); return; }
    saveTest(v('title'), dt, mx, mm);
  }
  closeModal(); render(); toast('Saved.');
});

/* ---------- boot ---------- */
render();
(function boot() {
  if (!DB.configured) { ui.booted = true; render(); return; }
  try { DB.initFirebase(); } catch (e) { ui.fatal = 'Supabase could not start. Check js/supabase-config.js.'; ui.booted = true; render(); return; }
  DB.getInfo().then(function (s) {
    ui.info = s.exists() ? s.data() : null;
    DB.watchAuth(onUser);
    setTimeout(function () { if (!ui.booted && !ui.session) { ui.booted = true; render(); } }, 4000);
  }).catch(function (e) {
    ui.booted = true;
    ui.fatal = e && e.code === 'permission-denied' ? 'The database is not set up yet. Run supabase/schema.sql in the Supabase SQL Editor.' : 'Could not reach the database. Check your internet connection and the settings in supabase-config.js.';
    render();
  });
})();
