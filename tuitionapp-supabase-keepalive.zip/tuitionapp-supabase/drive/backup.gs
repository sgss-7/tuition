/* Weekly TUITIONAPP backup to Google Drive.
   Runs inside your Google account (script.google.com). Steps are in README-SUPABASE.md, "Weekly backup to Google Drive".
   1. Paste your secret in BACKUP_KEY below (the same value you saved as BACKUP_KEY in Supabase).
   2. Run installWeeklyTrigger once, and allow access when Google asks.
   3. Run backupNow once to test: a "TUITIONAPP backups" folder appears in your Drive. */

const FUNCTION_URL = 'https://kgnmcomnebnuacmeydpf.supabase.co/functions/v1/export-backup';
const SUPABASE_URL = 'https://kgnmcomnebnuacmeydpf.supabase.co';
const ANON_KEY = 'sb_publishable_AkJYfdcDervAWv8CEvPM6Q_1AxKgqBq';   // the public anon key, same as js/supabase-config.js
const BACKUP_KEY = 'PASTE_YOUR_LONG_SECRET_HERE';
const FOLDER_NAME = 'TUITIONAPP backups';
const KEEP_DAYS = 120;                 // older backups are moved to the Drive trash
const TIMEZONE = 'Asia/Kathmandu';

function backupNow() {
  if (/PASTE/.test(BACKUP_KEY)) throw new Error('Paste your secret into BACKUP_KEY first.');
  const opts = { headers: { 'x-backup-key': BACKUP_KEY }, muteHttpExceptions: true };

  const res = UrlFetchApp.fetch(FUNCTION_URL, opts);
  if (res.getResponseCode() !== 200) throw new Error('Backup failed: HTTP ' + res.getResponseCode() + ' ' + res.getContentText().slice(0, 200));
  const text = res.getContentText();
  const check = JSON.parse(text);                                   // make sure it really is a backup
  if (check.app !== 'TUITIONAPP' || !check.data) throw new Error('Backup file looks wrong.');

  const it = DriveApp.getFoldersByName(FOLDER_NAME);
  const folder = it.hasNext() ? it.next() : DriveApp.createFolder(FOLDER_NAME);
  const name = 'tuitionapp-backup-' + Utilities.formatDate(new Date(), TIMEZONE, 'yyyy-MM-dd') + '.json';
  folder.createFile(name, text, MimeType.PLAIN_TEXT);

  UrlFetchApp.fetch(FUNCTION_URL + '?done=1', opts);                // tell the app the backup date

  const limit = new Date(Date.now() - KEEP_DAYS * 864e5);           // tidy up old copies
  const files = folder.getFiles();
  while (files.hasNext()) { const f = files.next(); if (f.getDateCreated() < limit) f.setTrashed(true); }
}

function installWeeklyTrigger() {
  ScriptApp.getProjectTriggers().forEach(function (t) { ScriptApp.deleteTrigger(t); });
  ScriptApp.newTrigger('backupNow').timeBased().onWeekDay(ScriptApp.WeekDay.SATURDAY).atHour(6).inTimezone(TIMEZONE).create();
  ScriptApp.newTrigger('keepAlive').timeBased().everyDays(2).atHour(3).inTimezone(TIMEZONE).create();   // stops the free Supabase project from pausing
}

/* Reads one row from the database every 2 days so Supabase never sees 7 quiet days (free projects pause after that). */
function keepAlive() {
  const res = UrlFetchApp.fetch(SUPABASE_URL + '/rest/v1/public_info?select=id&limit=1',
    { headers: { apikey: ANON_KEY, Authorization: 'Bearer ' + ANON_KEY }, muteHttpExceptions: true });
  if (res.getResponseCode() !== 200) throw new Error('Keep-alive failed: HTTP ' + res.getResponseCode() + ' ' + res.getContentText().slice(0, 200));
}
